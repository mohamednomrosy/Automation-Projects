package Pages.flight;

import Pages.Base.ElementsActions;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.Package.packagess;
import Pages.stays.checkout_recommended_stays;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.IOException;

public class flight {
    WebDriver driver;
    LoginPage page;
    //contractor
    public flight (WebDriver driver)
    {
        this.driver = driver;
    }
    private By flight_button = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[1]/ul/li[2]/a");
 
    private By leave_from = By.cssSelector("button[aria-label='Leaving from']");
    private By leave_from_city = By.cssSelector("input[placeholder='Leaving from']");
    private By select_city = By.cssSelector("button[aria-label='Search for “San Francisco, CA, United States of America (SFO-San Francisco Intl.)”']");

    private By going_to = By.cssSelector("button[aria-label='Going to']");
    private By going_to_city = By.cssSelector("input[placeholder='Going to']");
    private By select2_city = By.cssSelector("button[aria-label='Search for “Detroit, MI, United States of America (DTW-Detroit Metropolitan Wayne County)”']");


    private By dates = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/div/div[2]/form/div[1]/div/div[2]/div/div[1]/div/div/button");
    private By done = By.cssSelector("[data-stid='apply-date-selector']");
  
    private By travelers = By.cssSelector("[data-stid=\"open-room-picker\"]");
    private By adults = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/div/div[2]/form/div[1]/div/div[3]/div/div[2]/div/div/section/div[1]/div/div/button[2]");

    private By search_button = By.cssSelector("#search_button");
    
    private By depart_time = By.xpath("/html/body/div[2]/div[1]/div/div[2]/div[3]/div/div/div[2]/main/ul/li[26]/div/div/button");
    private By select_fare = By.xpath("/html/body/div[2]/div[1]/div/div[2]/div[3]/div/div/div[2]/main/ul/li[26]/div/div/section/div[2]/div/div/div[3]/div/div/div[1]/div[1]/li/div/div/div/div[3]/div/button");
    private By return_time = By.cssSelector("button[data-test-id='select-link']");
    private By select_fare2 = By.cssSelector("button[data-test-id='select-button']");
    
    private By no_thanks = By.cssSelector("a[aria-label='No thanks. Opens in a new tab']");

    private By checkout = By.xpath("//span[text()='Check out']");
    private By Go_to_checkout = By.xpath("//button[text()='Go to checkout']");

    private By phoneCountryCode = By.xpath("//select[@name='tripPreferencesRequest.airTripPreferencesRequest.travelerPreferences[0].phoneCountryCode']");
    private By option_phoneCountryCode = By.xpath("//select[@name='tripPreferencesRequest.airTripPreferencesRequest.travelerPreferences[0].phoneCountryCode']/option[@value='20']");
    private By phonenumber = By.id("phone-number[0]");

    private By gender = By.id("gender_male[0]");

    private By birth_month = By.xpath("//select[@name='tripPreferencesRequest.airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.month']");
    private By option_birth_month = By.xpath("//select[@name='tripPreferencesRequest.airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.month']/option[@value='12']");
  
    private By birth_day = By.xpath("//select[@name='tripPreferencesRequest.airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.day']");
    private By option_birth_day = By.xpath("//select[@name='tripPreferencesRequest.airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.day']/option[@value='10']");
    
    private By birth_year = By.xpath("//select[@name='tripPreferencesRequest.airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.year']");
    private By option_birth_year = By.xpath("//select[@name='tripPreferencesRequest.airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.year']/option[@value='2000']");

    


    //Actions

    public flight flight_button()
    {
        Helper.waitForElement(driver, flight_button);
        ElementsActions.clicker(driver, flight_button);
        return  this;
    }
    
    public flight leave_from()
    {
        Helper.waitForElement(driver, leave_from);
        ElementsActions.clicker(driver, leave_from);
        return  this;
    }
  
    public flight leave_from_city( String fieldName) throws IOException, ParseException {
    	Helper.waitForElement(driver , leave_from_city);
    	ElementsActions.sendText(driver , leave_from_city , fieldName);

    	return this;
    	}

    public flight select_city()
    {
        Helper.waitForElement(driver, select_city);
        ElementsActions.clicker(driver, select_city);
        return  this;
    }
    public flight going_to()
    {
        Helper.waitForElement(driver, going_to);
        ElementsActions.clicker(driver, going_to);
        return  this;
    }
    
    public flight going_to_city( String fieldName) throws IOException, ParseException {
    	Helper.waitForElement(driver , going_to_city);
    	ElementsActions.sendText(driver , going_to_city , fieldName);

    	return this;
    	}
    public flight select2_city()
    {
        Helper.waitForElement(driver, select2_city);
        ElementsActions.clicker(driver, select2_city);
        return  this;
    }
  
    public flight clickOndates()
    {
        Helper.waitForElement(driver, dates);
        ElementsActions.clicker(driver, dates);
        return  this;
    }
    public flight clickOnchoose_done()
    {
        Helper.waitForElement(driver, done);
        ElementsActions.clicker(driver, done);
        return  this;
    }
    public flight clickOntravelers()
    {
        Helper.waitForElement(driver, travelers);
        ElementsActions.clicker(driver, travelers);
        return  this;
    }
    public flight clickOnadults()
    {
        Helper.waitForElement(driver, adults);
        ElementsActions.clicker(driver, adults);
        return  this;
    }
    

public flight clickOnsearch_button()
{
    Helper.waitForElement(driver, search_button);
    ElementsActions.clicker(driver, search_button);
    return  this;
}
public flight depart_time()
{
    Helper.waitForElement(driver, depart_time);
    ElementsActions.clicker(driver, depart_time);
    return  this;
}
public flight select_fare()
{
    Helper.waitForElement(driver, select_fare);
    ElementsActions.clicker(driver, select_fare);
    return  this;
}
public flight return_time()
{
    Helper.waitForElement(driver, return_time);
    ElementsActions.clicker(driver, return_time);
    return  this;
}
public flight select_fare2()
{
    Helper.waitForElement(driver, select_fare2);
    ElementsActions.clicker(driver, select_fare2);
    return  this;
}

public flight no_thanks
()
{
    Helper.waitForElement(driver, no_thanks
);
    ElementsActions.clicker(driver, no_thanks
);
    return  this;
}


public flight checkout()
{
    Helper.waitForElement(driver, checkout);
    ElementsActions.clicker(driver, checkout);
    return  this;
}
public flight Go_to_checkout()
{
    Helper.waitForElement(driver, Go_to_checkout);
    ElementsActions.clicker(driver, Go_to_checkout);
    return  this;
}
public flight phoneCountryCode() {
    Helper.waitForElement(driver, phoneCountryCode);
    ElementsActions.clicker(driver, phoneCountryCode);
    return this;
}


public flight option_phoneCountryCode() {
    Helper.waitForElement(driver, option_phoneCountryCode);
    ElementsActions.clicker(driver, option_phoneCountryCode);
    return this;
}
public flight gender() {
    Helper.waitForElement(driver, gender);
    ElementsActions.clicker(driver, gender);
    return this;
} 
public flight birth_month() {
    Helper.waitForElement(driver, birth_month);
    ElementsActions.clicker(driver, birth_month);
    return this;
}


public flight option_birth_month() {
    Helper.waitForElement(driver, option_birth_month);
    ElementsActions.clicker(driver, option_birth_month);
    return this;
}

public flight birth_day() {
    Helper.waitForElement(driver, birth_day);
    ElementsActions.clicker(driver, birth_day);
    return this;
}


public flight option_birth_day() {
    Helper.waitForElement(driver, option_birth_day);
    ElementsActions.clicker(driver, option_birth_day);
    return this;
}

public flight birth_year() {
    Helper.waitForElement(driver, birth_year);
    ElementsActions.clicker(driver,birth_year);
    return this;
}

public flight option_birth_year() {
    Helper.waitForElement(driver, option_birth_year);
    ElementsActions.clicker(driver, option_birth_year);
    return this;
}

public flight enterphoneNumber( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , phonenumber);
ElementsActions.sendText(driver , phonenumber , fieldName);

return this;
}

}


