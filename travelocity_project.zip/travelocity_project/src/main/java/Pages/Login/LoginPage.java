package Pages.Login;

import Pages.Base.ElementsActions;
import Pages.Base.Helper;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import java.io.IOException;

public class LoginPage {
    WebDriver driver;

    //contractor
    public LoginPage (WebDriver driver)
    {
        this.driver = driver;
    }
    //locators
    private By emailField = By.id("loginFormEmailInput");
    private By password = By.id("loginFormPasswordInput");
    private By loginButton = By.xpath("/html/body/div[1]/div[1]/div/div/main/form/div[2]/button");
    private By title = By.tagName("h3");

    //Actions

    public LoginPage enterTheEmailAddress( String fieldName) throws IOException, ParseException {
        Helper.waitForElement(driver , emailField);
        ElementsActions.sendText(driver , emailField , fieldName);
        return this;
    }

    public LoginPage enterPassword( String fieldName) throws IOException, ParseException {
        Helper.waitForElement(driver , password);
        ElementsActions.sendText(driver , password , fieldName);
        return this;
    }

    public LoginPage clickOnLoginButton()
    {
        Helper.waitForElement(driver, loginButton);
        ElementsActions.clicker(driver, loginButton);
        return  this;
    }
    
public LoginPage title() {
    	
        Helper.waitForElement(driver, title);
       

        return this;
    }
    public LoginPage disableLoginButton() {
    	
        Helper.waitForElement(driver, loginButton);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].setAttribute('disabled', 'true');", loginButton);

        return this;
    }
}
