package Pages.car;

import Pages.Base.ElementsActions;
import Pages.Base.Helper;
import Pages.Login.LoginPage;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.io.IOException;

public class checkout_recommended_car {
    WebDriver driver;
    LoginPage page;
    //contractor
    public checkout_recommended_car (WebDriver driver)
    {
        this.driver = driver;
    }
    
    
    private By first_name = By.cssSelector("input[name='tripPreferencesRequest.hotelTripPreferences.hotelRoomPreferences[0].firstName']");

    private By last_name = By.cssSelector("input[name='tripPreferencesRequest.hotelTripPreferences.hotelRoomPreferences[0].lastName']");
    
    private By COUNTRY_CODE_DROPDOWN = By.id("oneLinePhoneNumberCountryCodeHiddenSelect");
    private By OPTION_EGYPT = By.xpath("//select[@id='sort-filter-dropdown-sort']/option[@value='20']");

    //private static final By COUNTRY_CODE_DROPDOWN = By.cssSelector("#oneLinePhoneNumberCountryCodeThreeLetterSelect");
   // private static final By OPTION_EGYPT = By.xpath("//select[@id='oneLinePhoneNumberCountryCodeHiddenSelect']/option[contains(text(), 'EGY +20')]");

    private By phonenumber = By.xpath("//input[@data-tealeaf-name='phoneNumber' and @name='tripPreferencesRequests[0].carTripPreferencesRequest.phoneNumber']");
    private By select_protection = By.name("insurance_piidcar");
    private By user_cardName = By.name("cardholder_name");
    private By user_cardNum = By.id("creditCardInput");
    
    private By exp_month = By.xpath("//select[@name='expiration_month']");
    private By option_exp_month = By.xpath("//select[@name='expiration_month']/option[@value='5']");

    private By exp_year = By.xpath("//select[@name='expiration_year']");
    private By option_exp_year = By.xpath("//select[@name='expiration_year']/option[@value='2024']");

    private By sec_code = By.name("new_card_security_code");
    private By zip_code = By.name("zipcode");
    
    private By phoneCountryCode = By.xpath("//select[@name='tripPreferencesRequests[0].carTripPreferencesRequest.phoneCountryCode']");
    private By option_phoneCountryCode = By.xpath("//select[@name='tripPreferencesRequests[0].carTripPreferencesRequest.phoneCountryCode']/option[@value='20']");

    private By ReserveNow = By.id("complete-booking");

    //Actions


//public checkout_recommended_stays enterfirstName( String fieldName) throws IOException, ParseException {
//    Helper.waitForElement(driver , first_name);
//    ElementsActions.sendText(driver , first_name , fieldName);
//
//    return this;
//}
//
//public checkout_recommended_stays enterlastName( String fieldName) throws IOException, ParseException {
//    Helper.waitForElement(driver , last_name);
//    ElementsActions.sendText(driver , last_name , fieldName);
//
//    return this;
//}



//public checkout_recommended_stays enterTheemail( String fieldName) throws IOException, ParseException {
//    Helper.waitForElement(driver , email);
//    ElementsActions.sendText(driver , email , fieldName);
//
//    return this;
//}

public checkout_recommended_car dropdownLocator_by() {
    Helper.waitForElement(driver, COUNTRY_CODE_DROPDOWN);
    ElementsActions.clicker(driver, COUNTRY_CODE_DROPDOWN);
    return this;
}

public checkout_recommended_car egyptOptionLocator_by() {
    Helper.waitForElement(driver, OPTION_EGYPT);
    ElementsActions.clicker(driver, OPTION_EGYPT);
    return this;
}

public checkout_recommended_car select_protection_yes() {
    Helper.waitForElement(driver, select_protection);
    ElementsActions.clicker(driver, select_protection);
    return this;
}

public checkout_recommended_car enter_usercardName( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , user_cardName);
ElementsActions.sendText(driver , user_cardName , fieldName);

return this;
}

public checkout_recommended_car enter_usercardNumber( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , user_cardNum);
ElementsActions.sendText(driver , user_cardNum , fieldName);

return this;
}

public checkout_recommended_car exp_month() {
    Helper.waitForElement(driver, exp_month);
    ElementsActions.clicker(driver, exp_month);
    return this;
}


public checkout_recommended_car option_exp_month() {
    Helper.waitForElement(driver, option_exp_month);
    ElementsActions.clicker(driver, option_exp_month);
    return this;
}

public checkout_recommended_car exp_year() {
    Helper.waitForElement(driver, exp_year);
    ElementsActions.clicker(driver, exp_year);
    return this;
}


public checkout_recommended_car option_exp_year() {
    Helper.waitForElement(driver, option_exp_year);
    ElementsActions.clicker(driver, option_exp_year);
    return this;
}

public checkout_recommended_car enterphoneNumber( String fieldName) throws IOException, ParseException {
    Helper.waitForElement(driver , phonenumber);
    ElementsActions.sendText(driver , phonenumber , fieldName);

    return this;
}
public checkout_recommended_car enter_sec_code( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , sec_code);
ElementsActions.sendText(driver , sec_code , fieldName);

return this;
}
public checkout_recommended_car enter_zip_code( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , zip_code);
ElementsActions.sendText(driver , zip_code , fieldName);

return this;
}
public checkout_recommended_car phoneCountryCode() {
    Helper.waitForElement(driver, phoneCountryCode);
    ElementsActions.clicker(driver, phoneCountryCode);
    return this;
}


public checkout_recommended_car option_phoneCountryCode() {
    Helper.waitForElement(driver, option_phoneCountryCode);
    ElementsActions.clicker(driver, option_phoneCountryCode);
    return this;
}
public checkout_recommended_car ReserveNow() {
    Helper.waitForElement(driver, ReserveNow);
    ElementsActions.clicker(driver, ReserveNow);
    return this;
}


}
