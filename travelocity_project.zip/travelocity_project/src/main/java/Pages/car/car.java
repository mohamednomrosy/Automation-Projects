package Pages.car;

import Pages.Base.ElementsActions;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.stays.checkout_recommended_stays;
import Pages.stays.recommended_Stays;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.IOException;

public class car {
    WebDriver driver;
    LoginPage page;
    //contractor
    public car (WebDriver driver)
    {
        this.driver = driver;
    }
    private By car_button = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[1]/ul/li[3]/a");

    private By leave_from = By.cssSelector("button[aria-label='Pick-up']");
    private By leave_from_city = By.cssSelector("input[placeholder='Pick-up']");
    private By select_city = By.cssSelector("button[aria-label='Downtown Cairo Cairo, Cairo Governorate, Egypt']");

    private By going_to = By.cssSelector("button[aria-label='Same as pick-up']");
    private By going_to_city = By.id("drop_off_location");
    private By select2_city = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[1]/div/figure/div[3]/div/form/div/div/div[1]/div[1]/div[2]/div/div/div/div/div[1]/div/div/section/div/div[2]/div/ul/li[2]/div/button");
    
    private By dates = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/form/div/div[3]/div/div[1]/div/div/button");
    private By done = By.cssSelector("[data-stid='apply-date-selector']");
  
    private By pick_up_time = By.id("pick_up_time");
    private By optionValue = By.cssSelector("select#pick_up_time option[value='1200AM']");

    private By drop_off_time = By.id("drop_off_time");
    private By optionValue2 = By.cssSelector("select#drop_off_time option[value='0300AM']");

    private By search_button = By.cssSelector("#search_button");
    
    private By rserve_car = By.cssSelector("div.uitk-text.uitk-type-300.uitk-text-default-theme.uitk-spacing.uitk-spacing-margin-blockend-one");
    private By rserve_car2 = By.cssSelector("button[name='reserve-btn']");

    
   
    //Actions

    public car car_button()
    {
        Helper.waitForElement(driver, car_button);
        ElementsActions.clicker(driver, car_button);
        return  this;
    }
    
    public car leave_from()
    {
        Helper.waitForElement(driver, leave_from);
        ElementsActions.clicker(driver, leave_from);
        return  this;
    }
  
    public car leave_from_city( String fieldName) throws IOException, ParseException {
    	Helper.waitForElement(driver , leave_from_city);
    	ElementsActions.sendText(driver , leave_from_city , fieldName);

    	return this;
    	}

    public car select_city()
    {
        Helper.waitForElement(driver, select_city);
        ElementsActions.clicker(driver, select_city);
        return  this;
    }
    public car going_to()
    {
        Helper.waitForElement(driver, going_to);
        ElementsActions.clicker(driver, going_to);
        return  this;
    }
    
    public car going_to_city( String fieldName) throws IOException, ParseException {
    	Helper.waitForElement(driver , going_to_city);
    	ElementsActions.sendText(driver , going_to_city , fieldName);
        driver.findElement(going_to_city).sendKeys(Keys.RETURN);
    	return this;
    	}
    public car select2_city()
    {
        Helper.waitForElement(driver, select2_city);
        ElementsActions.clicker(driver, select2_city);
        return  this;
    }
  
    public car clickOndates()
    {
        Helper.waitForElement(driver, dates);
        ElementsActions.clicker(driver, dates);
        return  this;
    }
    public car clickOnchoose_done()
    {
        Helper.waitForElement(driver, done);
        ElementsActions.clicker(driver, done);
        return  this;
    }


public car clickOnsearch_button()
{
    Helper.waitForElement(driver, search_button);
    ElementsActions.clicker(driver, search_button);
    return  this;
}
public car pick_up_time()
{
    Helper.waitForElement(driver, pick_up_time);
    ElementsActions.clicker(driver, pick_up_time);
    return  this;
}
public car option01()
{
    Helper.waitForElement(driver, optionValue);
    ElementsActions.clicker(driver, optionValue);
    return  this;
}

public car drop_off_time() {
    Helper.waitForElement(driver, drop_off_time);
    ElementsActions.clicker(driver, drop_off_time);
    return this;
}

public car option02() {
    Helper.waitForElement(driver, optionValue2);
    ElementsActions.clicker(driver, optionValue2);
    return this;
}
public car rserve_car() {
    Helper.waitForElement(driver, rserve_car);
    ElementsActions.clicker(driver, rserve_car);
    return this;
}
public car rserve_car2() {
    Helper.waitForElement(driver, rserve_car2);
    ElementsActions.clicker(driver, rserve_car2);
    return this;
}

}


