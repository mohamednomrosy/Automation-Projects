package Pages.stays;

import Pages.Base.ElementsActions;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.Package.packagess;
import Pages.car.car;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.IOException;

public class book_StaysPage {
    WebDriver driver;
    LoginPage page;
    //contractor
    public book_StaysPage (WebDriver driver)
    {
        this.driver = driver;
    }
    private By where_to = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/form/div/div/div[1]/div/div/div[2]/div[1]/button");
    private By dates = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/form/div/div/div[2]/div/div/div/div/button");
    private By done = By.cssSelector("[data-stid='apply-date-selector']");
    private By travelers = By.cssSelector("[data-stid=\"open-room-picker\"]");
    private By adults = By.cssSelector("button.uitk-layout-flex-item.uitk-step-input-touch-target > span.uitk-step-input-button > svg.uitk-icon.uitk-step-input-icon[aria-label=\"Increase the number of adults in room 1\"]\r\n"
    		+ "");
    private By childrens = By.cssSelector("button.uitk-layout-flex-item.uitk-step-input-touch-target svg[aria-label=\"Increase the number of children in room 1\"]\r\n"
    		+ "");
    private By select_age = By.id("age-traveler_selector_children_age_selector-0-0");
    private By optionValue = By.xpath("//option[text()='8']");

    private By another_room = By.cssSelector("button[data-test-id=\"traveler_selector_add_room\"].uitk-button.uitk-button-medium.uitk-button-has-text.uitk-button-tertiary\r\n"
    		+ "");
    private By adults2 = By.cssSelector("button.uitk-layout-flex-item.uitk-step-input-touch-target svg[aria-label=\"Increase the number of adults in room 2\"]\r\n"
    		+ "");
    private By childrens2 = By.cssSelector("button.uitk-layout-flex-item.uitk-step-input-touch-target svg[aria-label=\"Increase the number of children in room 2\"]\r\n"
    		+ "");
    private By select_age2 = By.id("age-traveler_selector_children_age_selector-1-0");
    private By optionValue2 = By.xpath("//select[@id='age-traveler_selector_children_age_selector-1-0']/option[@value='16']");

    private By done2 = By.cssSelector("#traveler_selector_done_button");
    
    private By search_button = By.cssSelector("#search_button");
    
    private By loved_button = By.xpath("/html/body/div[2]/div[1]/div/div/main/div/div/div/div/div/div[1]/section[2]/div/div[2]/div/div[2]/div[1]/div[2]/div[1]/div/div/div/div[1]/div/div/div/button");

    private By select_room =By.cssSelector("button[data-testid='uitk-gallery-item-current-trigger']");
    private By room_classification = By.xpath("/html/body/div[2]/div[1]/div/div/main/div/div/section/div[1]/div/div[2]/div/div[3]/div[7]/div/div/div[2]/div/div[1]/div/div[2]/div[1]/span/div/div[1]/div[2]/figure/button");
    private By close_room_classification =By.cssSelector("svg[aria-label='Close, go back to hotel details.']");
    private By reserve =By.cssSelector("button[data-stid='submit-hotel-reserve']");
    private By payNow =By.xpath("/html/body/div[2]/div[1]/div[2]/section/div[3]/div/div[2]/div/div/div[2]/button");
   
    private By phoneCountryCode = By.xpath("/html/body/div[4]/div[1]/div[11]/section[2]/article[1]/fieldset/fieldset/div[1]/fieldset/div[1]/fieldset/div[1]/div/select[2]");
    private By option_phoneCountryCode = By.xpath("//select[@name='tripPreferencesRequest.hotelTripPreferences.hotelRoomPreferences[0].preferredPhoneCountryCode']/option[@value='20']");

    
    //Actions

//    public book_StaysPage clickOnwhere_to()
//    {
//        Helper.waitForElement(driver, where_to);
//        ElementsActions.clicker(driver, where_to);
//        return  this;
//    }
  
    public book_StaysPage clickOnwhere_to( String fieldName) throws IOException, ParseException {
    	Helper.waitForElement(driver , where_to);
    	ElementsActions.sendText(driver , where_to , fieldName);
        driver.findElement(where_to).sendKeys(Keys.RETURN);
    	return this;
    	}
    
    public book_StaysPage clickOndates()
    {
        Helper.waitForElement(driver, dates);
        ElementsActions.clicker(driver, dates);
        return  this;
    }
    public book_StaysPage clickOnchoose_done()
    {
        Helper.waitForElement(driver, done);
        ElementsActions.clicker(driver, done);
        return  this;
    }
    public book_StaysPage clickOntravelers()
    {
        Helper.waitForElement(driver, travelers);
        ElementsActions.clicker(driver, travelers);
        return  this;
    }
    public book_StaysPage clickOnadults()
    {
        Helper.waitForElement(driver, adults);
        ElementsActions.clicker(driver, adults);
        return  this;
    }
    public book_StaysPage clickOnchildrens()
    {
        Helper.waitForElement(driver, childrens);
        ElementsActions.clicker(driver, childrens);
        return  this;
    }
    
    public book_StaysPage openDropdownList() {
        Helper.waitForElement(driver, select_age);
        ElementsActions.clicker(driver, select_age);
        return this;
    }

    public book_StaysPage selectOptionValue() {
        Helper.waitForElement(driver, optionValue);
        ElementsActions.clicker(driver, optionValue);
        return this;
    }
    
    public book_StaysPage clickOnanother_room()
    {
        Helper.waitForElement(driver, another_room);
        ElementsActions.clicker(driver, another_room);
        return  this;
    }
    public book_StaysPage clickOnadults2()
    {
        Helper.waitForElement(driver, adults2);
        ElementsActions.clicker(driver, adults2);
        return  this;
    }
    public book_StaysPage clickOnchildrens2()
    {
        Helper.waitForElement(driver, childrens2);
        ElementsActions.clicker(driver, childrens2);
        return  this;
    }
    public book_StaysPage openDropdownList2() {
        Helper.waitForElement(driver, select_age2);
        ElementsActions.clicker(driver, select_age2);
        return this;
    }

    public book_StaysPage selectOptionValue2() {
        Helper.waitForElement(driver, optionValue2);
        ElementsActions.clicker(driver, optionValue2);
        return this;
    }
   

public book_StaysPage clickOnchoose_done2()
{
    Helper.waitForElement(driver, done2);
    ElementsActions.clicker(driver, done2);
    return  this;
}
public book_StaysPage clickOnsearch_button()
{
    Helper.waitForElement(driver, search_button);
    ElementsActions.clicker(driver, search_button);
    return  this;
}
public book_StaysPage loved_button()
{
    Helper.waitForElement(driver, loved_button);
    ElementsActions.clicker(driver, loved_button);
    return  this;
}

public book_StaysPage select_room() {
	Helper.waitForElement(driver , select_room );
	ElementsActions.clicker(driver , select_room );

    return this;
}
public book_StaysPage chosse_room_classification() {
	Helper.waitForElement(driver , room_classification );
	ElementsActions.clicker(driver , room_classification );

    return this;
}
public book_StaysPage close_room_classification() {
	Helper.waitForElement(driver , close_room_classification );
	ElementsActions.clicker(driver , close_room_classification );

    return this;
}

public book_StaysPage reserve() {
	Helper.waitForElement(driver , reserve );
	ElementsActions.clicker(driver , reserve );

    return this;
}
public book_StaysPage payNow() {
	Helper.waitForElement(driver , payNow );
	ElementsActions.clicker(driver , payNow );

    return this;
}
public book_StaysPage phoneCountryCode() {
    Helper.waitForElement(driver, phoneCountryCode);
    ElementsActions.clicker(driver, phoneCountryCode);
    return this;
}


public book_StaysPage option_phoneCountryCode() {
    Helper.waitForElement(driver, option_phoneCountryCode);
    ElementsActions.clicker(driver, option_phoneCountryCode);
    return this;
}
}

