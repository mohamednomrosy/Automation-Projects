package Pages.stays;

import Pages.Base.ElementsActions;
import Pages.Base.Helper;
import Pages.Login.LoginPage;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.IOException;

public class recommended_Stays {
    WebDriver driver;
    //contractor
    public recommended_Stays (WebDriver driver)
    {
        this.driver = driver;
    }
    
    
    private By explorestays = By.cssSelector("a[href*='travelocity.com/Hotel-Search'][aria-label='Alexandria']");

    private By sort_by = By.id("sort-filter-dropdown-sort");
    private By optionValue3 = By.xpath("//select[@id='sort-filter-dropdown-sort']/option[@value='PROPERTY_CLASS']");
    
    private By minprice   = By.id("price-min");
    private By maxprice   = By.id("price-max");
    private By filters_first = By.cssSelector("button[data-testid='uitk-gallery-item-current-trigger'][aria-label='More information about SUNRISE Alex Avenue Hotel, opens in a new tab']");
    private By select_room = By.cssSelector("button[data-stid='sticky-button']");
    private By room_classification = By.cssSelector("button[data-testid='uitk-gallery-item-current-trigger'][aria-label='View all photos for Junior Jacuzzi Suite");
    private By close_room_classification =By.cssSelector("svg[aria-label='Close, go back to hotel details.']");
    private By reserve =By.cssSelector("button[data-stid='submit-hotel-reserve']");
    private By payNow =By.xpath("/html/body/div[2]/div[1]/div[2]/section/div[3]/div/div[2]/div/div/div[2]/button");

    //Actions

   

public recommended_Stays clickOnexplorestays()
{
    Helper.waitForElement(driver, explorestays);
    ElementsActions.clicker(driver, explorestays);
    return  this;
}

public recommended_Stays enterTheminPrice( String fieldName) throws IOException, ParseException {
    Helper.waitForElement(driver , minprice);
    ElementsActions.sendText(driver , minprice , fieldName);

    return this;
}
public recommended_Stays enterThemaxPrice( String fieldName) throws IOException, ParseException {
    Helper.waitForElement(driver , maxprice);
    ElementsActions.sendText(driver , maxprice , fieldName);

    return this;
}

public recommended_Stays open_sort_by() {
    Helper.waitForElement(driver, sort_by);
    ElementsActions.clicker(driver, sort_by);
    return this;
}

public recommended_Stays selectOptionValue3() {
    Helper.waitForElement(driver, optionValue3);
    ElementsActions.clicker(driver, optionValue3);
    return this;
}

public recommended_Stays chosse_filters_first() {
	Helper.waitForElement(driver , filters_first );
	ElementsActions.clicker(driver , filters_first );

    return this;
}
public recommended_Stays select_room() {
	Helper.waitForElement(driver , select_room );
	ElementsActions.clicker(driver , select_room );

    return this;
}
public recommended_Stays chosse_room_classification() {
	Helper.waitForElement(driver , room_classification );
	ElementsActions.clicker(driver , room_classification );

    return this;
}
public recommended_Stays close_room_classification() {
	Helper.waitForElement(driver , close_room_classification );
	ElementsActions.clicker(driver , close_room_classification );

    return this;
}

public recommended_Stays reserve() {
	Helper.waitForElement(driver , reserve );
	ElementsActions.clicker(driver , reserve );

    return this;
}

public recommended_Stays payNow() {
	Helper.waitForElement(driver , payNow );
	ElementsActions.clicker(driver , payNow );

    return this;
}

public recommended_Stays clear() {
    ElementsActions.clearText(driver , minprice );
    ElementsActions.clearText(driver , maxprice );

    return this;
}
}


