package Pages.Base;

import io.qameta.allure.Allure;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

public  class Helper {
    
    public static void waitForElement(WebDriver driver,By locator)
    {
        WebDriverWait wait = new WebDriverWait(driver , Duration.ofSeconds(80));
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }
    
    public static void wait_(int durationInSeconds) {
        try {
            Thread.sleep(durationInSeconds * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }}

