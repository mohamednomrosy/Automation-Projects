package Pages.Base;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Browser {
    private static WebDriver driver ;
    private static String url = "https://www.travelocity.com/login?";
    private static String ur2 = "https://www.travelocity.com";

    public static WebDriver setBrowser()
    {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(url);
        return Browser.driver;
    }
    
    public static WebDriver setBrowser2()
    {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(ur2);
        return Browser.driver;
    }

    public static void quit()
    {
        driver.quit();
    }
    public static void back()
    {
        driver.navigate().back();
    }
    
    public static void return_to_Tab(int i)
    {
        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(i)); // Switch to the new tab

//        // العودة إلى علامة التبويب الأصلية
//        driver.switchTo().window(tabs.get(0));
        // Close the new tab
//        driver.close();

        // Switch back to the original tab
//        driver.switchTo().window(originalTab);
    }
    
    public static void closeNewTabAndTest()
    {
        driver.close();

        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());

        // العودة إلى علامة التبويب الأصلية
        driver.switchTo().window(tabs.get(1));
        // Close the new tab
//        driver.close();

        // Switch back to the original tab
//        driver.switchTo().window(originalTab);
    }
    public static String getUrl() {
        return url;
    }

}
