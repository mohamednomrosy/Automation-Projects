package Pages.cruise;

import Pages.Base.ElementsActions;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.Package.packagess;
import Pages.flight.flight;
import Pages.stays.checkout_recommended_stays;
import Pages.stays.recommended_Stays;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.IOException;

public class cruise {
    WebDriver driver;
    LoginPage page;
    //contractor
    public cruise (WebDriver driver)
    {
        this.driver = driver;
    }
    private By cruise_button = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[1]/ul/li[6]/a");

    private By going_to = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/form/div/div/div[1]/div/div/div/div[1]/button");
    private By going_to_city = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/form/div/div/div[1]/div/div/div/section/div/div[1]/div/div/input");
    private By europe = By.cssSelector("button[aria-label='Europe']");

    private By dates = By.cssSelector("button[aria-label='Departing between, Sep 2 - Oct 2']");
    private By done = By.cssSelector("[data-stid='apply-date-selector']");
   
    private By duration = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/form/div/div/div[3]/div/div[1]/button");
    private By min_duration = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/form/div/div/div[3]/div/div[2]/div/section/div/div[1]/div[1]/input");
    private By max_duration = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/form/div/div/div[3]/div/div[2]/div/section/div/div[2]/div[1]/input");
    private By done2 = By.id("duration_span_selector_done_button");

    private By traveller = By.cssSelector("button[data-stid='open-room-picker']");
    private By decrease_adult = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/form/div/div/div[4]/div/div[2]/div/div/section/div[1]/div/div/button[1]");
    private By increase_child = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/form/div/div/div[4]/div/div[2]/div/div/section/div[2]/div[1]/div/button[2]");
    private By select_age_travelers = By.xpath("//select[@id='age-traveler_selector_children_age_selector-0']");
    private By option_age_5 = By.xpath("//select[@id='age-traveler_selector_children_age_selector-0']/option[@value='5']");
    private By done3 = By.id("traveler_selector_done_button");

    private By cruise_line1 = By.xpath("/html/body/div[2]/div[1]/div/div/div/main/div/div/div/div/div/div/div[2]/div/form/div/div[2]/div/fieldset/div[1]/div/div/div/label/p");
    private By cruise_line2 = By.xpath("/html/body/div[2]/div[1]/div/div/div/main/div/div/div/div/div[1]/div/div[2]/div/form/div/div[2]/div/fieldset/div[2]/div/div/div/label/p");
    private By cruise_line3 = By.xpath("/html/body/div[2]/div[1]/div/div/div/main/div/div/div/div/div[1]/div/div[2]/div/form/div/div[2]/div/fieldset/div[3]/div/div/div/label/p");
    private By cruise_line4 = By.xpath("/html/body/div[2]/div[1]/div/div/div/main/div/div/div/div/div[1]/div/div[2]/div/form/div/div[2]/div/fieldset/div[4]/div/div/div/label/p");
    private By room_exp = By.xpath("/html/body/div[2]/div[1]/div/div/div/main/div/div/div/div/div[1]/div/div[2]/div/form/div/div[4]/div/fieldset/fieldset/div[4]/div/div/div/label/span[2]");

    private By select_europe_night = By.cssSelector("#listing-content-entry");
    private By continue_button = By.xpath("/html/body/div[2]/div[1]/div/div/div[2]/div/div/div[2]/div[2]/div/div[2]/div/div/div/div[2]/div/div[2]/div/div[2]/div/button");
    private By select_room_night = By.xpath("/html/body/div[2]/div[1]/div/div/div[2]/div/div/div[2]/section/div/div/div[4]/div/div[1]/div/div[2]/div/div/div[3]/div/div/div/div/div/div[2]/a");
    private By reserve = By.xpath("/html/body/div[2]/div[1]/div/div/div/div[2]/div/div[1]/div[4]/div[2]/div/div/div[5]/a");

    private By title = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].title']");
    private By option_title = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].title']/option[@value='MR']");
    
    private By country = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].citizenship']");
    private By option_country = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].citizenship']/option[@value='AF']");
   
    private By gender = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].gender']");
    private By option_gender = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].gender']/option[@value='M']");

    private By birth_month = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].birthDetails.birthMonth']");
    private By option_birth_month = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].birthDetails.birthMonth']/option[@value='12']");
  
    private By birth_day = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].birthDetails.birthDay']");
    private By option_birth_day = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].birthDetails.birthDay']/option[@value='10']");
    
    private By birth_year = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].birthDetails.birthYear']");
    private By option_birth_year = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[0].birthDetails.birthYear']/option[@value='2000']");

    private By country_code = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.phoneCountryCode']");
    private By country_code_option = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.phoneCountryCode']/option[@value='20']");
    private By phone = By.name("tripPreferencesRequest.cruiseTripPreferencesRequest.phoneNumber");

    private By title2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].title']");
    private By option_title2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].title']/option[@value='MR']");
    
    private By country2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].citizenship']");
    private By option_country2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].citizenship']/option[@value='AF']");
   
    private By gender2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].gender']");
    private By option_gender2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].gender']/option[@value='M']");

    private By birth_month2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].birthDetails.birthMonth']");
    private By option_birth_month2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].birthDetails.birthMonth']/option[@value='12']");
  
    private By birth_day2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].birthDetails.birthDay']");
    private By option_birth_day2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].birthDetails.birthDay']/option[@value='10']");
    
    private By birth_year2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].birthDetails.birthYear']");
    private By option_birth_year2 = By.xpath("//select[@name='tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].birthDetails.birthYear']/option[@value='2000']");
    
    private By firstName = By.name("tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].firstName");
    private By lastName = By.name("tripPreferencesRequest.cruiseTripPreferencesRequest.passengerPreferences[1].lastName");

    private By nameonCard = By.name("cardholder_name");
    private By country_card = By.name("country");
    private By option_country_card = By.xpath("//select[@name='country']/option[@value='USA']");
    private By billingAdress1 = By.cssSelector("input[data-tealeaf-name='street']");
    private By billingAdress2 = By.cssSelector("input[data-tealeaf-name='street2']");
    //Actions

    public cruise cruise_button()
    {
        Helper.waitForElement(driver, cruise_button);
        ElementsActions.clicker(driver, cruise_button);
        return  this;
    }

    
    public cruise going_to(){
    	Helper.waitForElement(driver , going_to);
        ElementsActions.clicker(driver, going_to);
//        driver.findElement(going_to_city).sendKeys(Keys.RETURN);
    	return this;
    	}
    
    public cruise going_to_city( String fieldName) throws IOException, ParseException {
    	ElementsActions.sendText(driver , going_to_city , fieldName);
      driver.findElement(going_to_city).sendKeys(Keys.ENTER);
    	return this;
    	}
    public cruise europe()
    {
        Helper.waitForElement(driver, europe);
        ElementsActions.clicker(driver, europe);
        return  this;
    }
    public cruise clickOndates()
    {
        Helper.waitForElement(driver, dates);
        ElementsActions.clicker(driver, dates);
        return  this;
    }
    public cruise clickOnchoose_done()
    {
        Helper.waitForElement(driver, done);
        ElementsActions.clicker(driver, done);
        return  this;
    }
    public cruise duration()
    {
        Helper.waitForElement(driver, duration);
        ElementsActions.clicker(driver, duration);
        return  this;
    }
    public cruise min_duration( String fieldName) throws IOException, ParseException {
        ElementsActions.clicker(driver, min_duration);
        driver.findElement(min_duration).clear();
    	ElementsActions.sendText(driver , min_duration , fieldName);
    	return this;
    	}
    public cruise max_duration( String fieldName) throws IOException, ParseException {
        ElementsActions.clicker(driver, max_duration);
        driver.findElement(max_duration).clear();
    	ElementsActions.sendText(driver , max_duration , fieldName);
    	return this;
    	}
    public cruise clickOnchoose_done2()
    {
        Helper.waitForElement(driver, done2);
        ElementsActions.clicker(driver, done2);
        return  this;
    }
    
    public cruise traveller()
    {
        Helper.waitForElement(driver, traveller);
        ElementsActions.clicker(driver, traveller);
        return  this;
    }
    
    public cruise decrease_adult()
    {
        Helper.waitForElement(driver, decrease_adult);
        ElementsActions.clicker(driver, decrease_adult);
        return  this;
    }
    
    public cruise increase_child()
    {
        Helper.waitForElement(driver, increase_child);
        ElementsActions.clicker(driver, increase_child);
        return  this;
    }
    public cruise select_age_travelers() {
        Helper.waitForElement(driver, select_age_travelers);
        ElementsActions.clicker(driver, select_age_travelers);
        return this;
    }
    public cruise option_age_5() {
        Helper.waitForElement(driver, option_age_5);
        ElementsActions.clicker(driver, option_age_5);
        return this;
    }
    public cruise clickOnchoose_done3()
    {
        Helper.waitForElement(driver, done3);
        ElementsActions.clicker(driver, done3);
        return  this;
    }
    public cruise cruise_line1()
    {
        Helper.waitForElement(driver, cruise_line1);
        ElementsActions.clicker(driver, cruise_line1);
        return  this;
    }
    public cruise cruise_line2()
    {
        Helper.waitForElement(driver, cruise_line2);
        ElementsActions.clicker(driver, cruise_line2);
        return  this;
    }
    public cruise cruise_line3()
    {
        Helper.waitForElement(driver, cruise_line3);
        ElementsActions.clicker(driver, cruise_line3);
        return  this;
    }
    public cruise cruise_line4()
    {
        Helper.waitForElement(driver, cruise_line4);
        ElementsActions.clicker(driver, cruise_line4);
        return  this;
    }
    public cruise room_exp()
    {
        Helper.waitForElement(driver, room_exp);
        ElementsActions.clicker(driver, room_exp);
        return  this;
    }
    public cruise select_europe_night()
    {
        Helper.waitForElement(driver, select_europe_night);
        ElementsActions.clicker(driver, select_europe_night);
        return  this;
    }  
    public cruise continue_button()
    {
        Helper.waitForElement(driver, continue_button);
        ElementsActions.clicker(driver, continue_button);
        return  this;
    }
    public cruise select_room_night()
    {
        Helper.waitForElement(driver, select_room_night);
        ElementsActions.clicker(driver, select_room_night);
        return  this;
    }
    public cruise reserve()
    {
        Helper.waitForElement(driver, reserve);
        ElementsActions.clicker(driver, reserve);
        return  this;
    } 
    public cruise country() {
        Helper.waitForElement(driver, country);
        ElementsActions.clicker(driver, country);
        return this;
    } 
    public cruise option_country() {
        Helper.waitForElement(driver, option_country);
        ElementsActions.clicker(driver, option_country);
        return this;
    }
    public cruise title() {
        Helper.waitForElement(driver, title);
        ElementsActions.clicker(driver, title);
        return this;
    } 
    public cruise option_title() {
        Helper.waitForElement(driver, option_title);
        ElementsActions.clicker(driver, option_title);
        return this;
    }
    public cruise gender() {
        Helper.waitForElement(driver, gender);
        ElementsActions.clicker(driver, gender);
        return this;
    } 
    public cruise option_gender() {
        Helper.waitForElement(driver, option_gender);
        ElementsActions.clicker(driver, option_gender);
        return this;
    }
    public cruise birth_month() {
        Helper.waitForElement(driver, birth_month);
        ElementsActions.clicker(driver, birth_month);
        return this;
    }


    public cruise option_birth_month() {
        Helper.waitForElement(driver, option_birth_month);
        ElementsActions.clicker(driver, option_birth_month);
        return this;
    }

    public cruise birth_day() {
        Helper.waitForElement(driver, birth_day);
        ElementsActions.clicker(driver, birth_day);
        return this;
    }


    public cruise option_birth_day() {
        Helper.waitForElement(driver, option_birth_day);
        ElementsActions.clicker(driver, option_birth_day);
        return this;
    }

    public cruise birth_year() {
        Helper.waitForElement(driver, birth_year);
        ElementsActions.clicker(driver,birth_year);
        return this;
    }

    public cruise option_birth_year() {
        Helper.waitForElement(driver, option_birth_year);
        ElementsActions.clicker(driver, option_birth_year);
        return this;
    }
    public cruise country_code()
    {
        Helper.waitForElement(driver, country_code);
        ElementsActions.clicker(driver, country_code);
        return  this;
    }
    public cruise country_code_option()
    {
        Helper.waitForElement(driver, country_code_option);
        ElementsActions.clicker(driver, country_code_option);
        return  this;
    }
    public cruise phone( String fieldName) throws IOException, ParseException {
        ElementsActions.clicker(driver, phone);
    	ElementsActions.sendText(driver , phone , fieldName);
    	return this;
    	}
    public cruise firstName( String fieldName) throws IOException, ParseException {
        ElementsActions.clicker(driver, firstName);
    	ElementsActions.sendText(driver , firstName , fieldName);
    	return this;
    	}
    public cruise lastName( String fieldName) throws IOException, ParseException {
        ElementsActions.clicker(driver, lastName);
    	ElementsActions.sendText(driver , lastName , fieldName);
    	return this;
    	}
    public cruise country2() {
        Helper.waitForElement(driver, country2);
        ElementsActions.clicker(driver, country2);
        return this;
    } 
    public cruise option_country2() {
        Helper.waitForElement(driver, option_country2);
        ElementsActions.clicker(driver, option_country2);
        return this;
    }
    public cruise title2() {
        Helper.waitForElement(driver, title2);
        ElementsActions.clicker(driver, title2);
        return this;
    } 
    public cruise option_title2() {
        Helper.waitForElement(driver, option_title2);
        ElementsActions.clicker(driver, option_title2);
        return this;
    }
    public cruise gender2() {
        Helper.waitForElement(driver, gender2);
        ElementsActions.clicker(driver, gender2);
        return this;
    } 
    public cruise option_gender2() {
        Helper.waitForElement(driver, option_gender2);
        ElementsActions.clicker(driver, option_gender2);
        return this;
    }
    public cruise birth_month2() {
        Helper.waitForElement(driver, birth_month2);
        ElementsActions.clicker(driver, birth_month2);
        return this;
    }


    public cruise option_birth_month2() {
        Helper.waitForElement(driver, option_birth_month2);
        ElementsActions.clicker(driver, option_birth_month2);
        return this;
    }

    public cruise birth_day2() {
        Helper.waitForElement(driver, birth_day2);
        ElementsActions.clicker(driver, birth_day2);
        return this;
    }


    public cruise option_birth_day2() {
        Helper.waitForElement(driver, option_birth_day2);
        ElementsActions.clicker(driver, option_birth_day2);
        return this;
    }

    public cruise birth_year2() {
        Helper.waitForElement(driver, birth_year2);
        ElementsActions.clicker(driver,birth_year2);
        return this;
    }

    public cruise option_birth_year2() {
        Helper.waitForElement(driver, option_birth_year2);
        ElementsActions.clicker(driver, option_birth_year2);
        return this;
    }
    public cruise nameonCard( String fieldName) throws IOException, ParseException {
        ElementsActions.clicker(driver, nameonCard);
    	ElementsActions.sendText(driver , nameonCard , fieldName);
    	return this;
    	}
    public cruise country_card() {
        Helper.waitForElement(driver, country_card);
        ElementsActions.clicker(driver, country_card);
        return this;
    }
    public cruise option_country_card() {
        Helper.waitForElement(driver, option_country_card);
        ElementsActions.clicker(driver, option_country_card);
        return this;
    }
    public cruise enter_billingAdress1( String fieldName) throws IOException, ParseException {
    	Helper.waitForElement(driver , billingAdress1);
    	ElementsActions.sendText(driver , billingAdress1 , fieldName);

    	return this;
    	}
    	public cruise enter_billingAdress2( String fieldName) throws IOException, ParseException {
    	Helper.waitForElement(driver , billingAdress2);
    	ElementsActions.sendText(driver , billingAdress2 , fieldName);

    	return this;
    	}
}


