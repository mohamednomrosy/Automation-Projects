package Pages.Package;

import Pages.Base.ElementsActions;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.car.checkout_recommended_car;
import Pages.flight.flight;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.IOException;

public class packagess {
    WebDriver driver;
    LoginPage page;
    //contractor
    public packagess (WebDriver driver)
    {
        this.driver = driver;
    }
    
    private By package_button = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[1]/ul/li[4]/a/span");
    private By car_button = By.xpath("//span[text()='Car']");

    private By where_to = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/form/div/div/div[1]/div/div/div[2]/div[1]/button");
    private By choose_dest = By.cssSelector("[data-stid='destination_form_field-result-item-button']");
    private By dates = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/form/div[1]/div[2]/div/div[1]/div/div/button");
    private By done = By.cssSelector("[data-stid='apply-date-selector']");
    private By travelers = By.cssSelector("[data-stid=\"open-room-picker\"]");
    private By adults = By.cssSelector("button.uitk-layout-flex-item.uitk-step-input-touch-target > span.uitk-step-input-button > svg.uitk-icon.uitk-step-input-icon[aria-label=\"Increase the number of adults in room 1\"]\r\n"
    		+ "");
    private By childrens = By.cssSelector("button.uitk-layout-flex-item.uitk-step-input-touch-target svg[aria-label=\"Increase the number of children in room 1\"]\r\n"
    		+ "");
    private By select_age = By.id("age-traveler_selector_children_age_selector-0-0");
    private By optionValue = By.xpath("//option[text()='8']");
    private By chosse_filters_first = By.xpath("/html/body/div[2]/div[1]/div/div/main/div/div/div/div/div/div[1]/section[2]/div/div[3]/div/div[2]/div[2]/div[2]/div[1]/div/div/div/div[1]/figure/span/span/div/div[1]/div[2]/figure/button\r\n"
    		+ "");
    private By select_room = By.xpath("/html/body/div[2]/div[1]/div/div/main/div/div/section/div[1]/div/div[2]/div/div[3]/div[7]/div/div/div[2]/div/div[2]/div/div[2]/div/div/div[2]/div[2]/button");
    private By close_room_classification =By.cssSelector("svg[aria-label='Close, go back to hotel details.']");
    private By reserve =By.xpath("/html/body/div[2]/div[1]/div/div/main/div/div/section/div[1]/div/div[2]/div/div[3]/div[7]/div/div/div[2]/div/div[2]/div/div[2]/div/div/div[2]/div[2]/button");

    private By depart_time = By.cssSelector("button[data-test-id='select-link']");
    private By select_fare = By.cssSelector("button[data-test-id='select-button']");
    private By return_time = By.cssSelector("button[data-test-id='select-link']");
    private By select_fare2 = By.cssSelector("button[data-test-id='select-button']");
    private By rserve_car = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div[2]/div/div[1]/div[3]/div[2]/div[2]/ol/li[2]/div/div/div[2]/div/div[2]/button");

    private By phonenumber = By.xpath("/html/body/div[6]/div[1]/section[2]/div[4]/section[1]/section[1]/article/fieldset/div[1]/div/div/label[2]/input");
    private By trip_protection = By.id("yes_insurance_package");
    private By car_protection = By.id("yes_insurance");
    private By user_cardName = By.name("cardholder_name");
    private By user_cardNum = By.id("creditCardInput");
    
    private By exp_month = By.xpath("//select[@name='expiration_month']");
    private By option_exp_month = By.xpath("//select[@name='expiration_month']/option[@value='5']");

    private By exp_year = By.xpath("//select[@name='expiration_year']");
    private By option_exp_year = By.xpath("//select[@name='expiration_year']/option[@value='2024']");

    private By sec_code = By.name("new_card_security_code");
    private By zip_code = By.name("zipcode");
    
    private By phoneCountryCode = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[0].phoneCountryCode']");
    private By option_phoneCountryCode = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[0].phoneCountryCode']/option[@value='20']");
    private By gender = By.id("maleRadio0");

    private By birth_month = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.month']");
    private By option_birth_month = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.month']/option[@value='12']");
  
    private By birth_day = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.day']");
    private By option_birth_day = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.day']/option[@value='10']");
    
    private By birth_year = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.year']");
    private By option_birth_year = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[0].dateOfBirth.year']/option[@value='2000']");

    private By select_traveller = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[1].travelerName']");
    private By option_select_traveller = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[1].travelerName']/option[text()='Mohamed  Mamdouh']");

    private By traveller_first_name = By.id("firstname[1]");
    private By traveller_last_name = By.id("lastname[1]");

    private By gender2 = By.id("femaleRadio1");

    private By birth_month2 = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[1].dateOfBirth.month");
    private By option_birth_month2 = By.xpath("//select[@name='tripPreferencesRequests[0].airTripPreferencesRequest.travelerPreferences[1].dateOfBirth.month']/option[@value='9']");
  
    private By birth_day2 = By.xpath("//select[@name='tripPreferencesRequests[1].airTripPreferencesRequest.travelerPreferences[1].dateOfBirth.day']");
    private By option_birth_day2 = By.xpath("//select[@name='tripPreferencesRequests[1].airTripPreferencesRequest.travelerPreferences[1].dateOfBirth.day']/option[@value='10']");
    
    private By birth_year2 = By.xpath("//select[@name='tripPreferencesRequests[1].airTripPreferencesRequest.travelerPreferences[1].dateOfBirth.year']");
    private By option_birth_year2 = By.xpath("//select[@name='tripPreferencesRequests[1].airTripPreferencesRequest.travelerPreferences[1].dateOfBirth.year']/option[@value='1975']");
   
    private By country = By.name("country");
    private By option_country = By.xpath("//select[@name='country']/option[@value='USA']");
    
    private By billingAdress1 = By.name("street");
    private By billingAdress2 = By.name("street2");
  
    private By city = By.name("city");
    private By state = By.name("state");
    
    private By remember_card = By.id("save-card");


    //Actions

    public packagess clickOnwhere_to()
    {
        Helper.waitForElement(driver, where_to);
        ElementsActions.clicker(driver, where_to);
        return  this;
    }
    public packagess Choose_destination()
    {
        Helper.waitForElement(driver, choose_dest);
        ElementsActions.clicker(driver, choose_dest);
        return  this;
    }
    
    public packagess clickOndates()
    {
        Helper.waitForElement(driver, dates);
        ElementsActions.clicker(driver, dates);
        return  this;
    }
    public packagess clickOnchoose_done()
    {
        Helper.waitForElement(driver, done);
        ElementsActions.clicker(driver, done);
        return  this;
    }
    public packagess clickOntravelers()
    {
        Helper.waitForElement(driver, travelers);
        ElementsActions.clicker(driver, travelers);
        return  this;
    }
    public packagess clickOnadults()
    {
        Helper.waitForElement(driver, adults);
        ElementsActions.clicker(driver, adults);
        return  this;
    }
    public packagess clickOnchildrens()
    {
        Helper.waitForElement(driver, childrens);
        ElementsActions.clicker(driver, childrens);
        return  this;
    }
    
    public packagess openDropdownList() {
        Helper.waitForElement(driver, select_age);
        ElementsActions.clicker(driver, select_age);
        return this;
    }

    public packagess package_button() {
        Helper.waitForElement(driver, package_button);
        ElementsActions.clicker(driver, package_button);
        return this;
    }
    public packagess car_button() {
        Helper.waitForElement(driver, car_button);
        ElementsActions.clicker(driver, car_button);
        return this;
    }
    public packagess gender() {
        Helper.waitForElement(driver, gender);
        ElementsActions.clicker(driver, gender);
        return this;
    } 
    public packagess gender2() {
        Helper.waitForElement(driver, gender2);
        ElementsActions.clicker(driver, gender2);
        return this;
    }  
    public packagess chosse_filters_first() {
        Helper.waitForElement(driver, chosse_filters_first);
        ElementsActions.clicker(driver, chosse_filters_first);
        return this;
    }

    public packagess select_room() {
        Helper.waitForElement(driver, select_room);
        ElementsActions.clicker(driver, select_room);
        return this;
    }

    public packagess close_room_classification() {
        Helper.waitForElement(driver, close_room_classification);
        ElementsActions.clicker(driver, close_room_classification);
        return this;
    }
    public packagess reserve() {
        Helper.waitForElement(driver, reserve);
        ElementsActions.clicker(driver, reserve);
        return this;
    }

    public packagess depart_time()
    {
        Helper.waitForElement(driver, depart_time);
        ElementsActions.clicker(driver, depart_time);
        return  this;
    }
    public packagess select_fare()
    {
        Helper.waitForElement(driver, select_fare);
        ElementsActions.clicker(driver, select_fare);
        return  this;
    }
    public packagess return_time()
    {
        Helper.waitForElement(driver, return_time);
        ElementsActions.clicker(driver, return_time);
        return  this;
    }
    public packagess select_fare2()
    {
        Helper.waitForElement(driver, select_fare2);
        ElementsActions.clicker(driver, select_fare2);
        return  this;
    }

    public packagess rserve_car
    ()
    {
        Helper.waitForElement(driver, rserve_car
    );
        ElementsActions.clicker(driver, rserve_car
    );
        return  this;
    }
    

public packagess trip_protection() {
    Helper.waitForElement(driver, trip_protection);
    ElementsActions.clicker(driver, trip_protection);
    return this;
}
public packagess car_protection() {
    Helper.waitForElement(driver, car_protection);
    ElementsActions.clicker(driver, car_protection);
    return this;
}
public packagess remember_card() {
    Helper.waitForElement(driver, remember_card);
    ElementsActions.clicker(driver, remember_card);
    return this;
}
public packagess enter_usercardNumber( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , user_cardNum);
ElementsActions.sendText(driver , user_cardNum , fieldName);

return this;
}

public packagess exp_month() {
    Helper.waitForElement(driver, exp_month);
    ElementsActions.clicker(driver, exp_month);
    return this;
}


public packagess option_exp_month() {
    Helper.waitForElement(driver, option_exp_month);
    ElementsActions.clicker(driver, option_exp_month);
    return this;
}

public packagess exp_year() {
    Helper.waitForElement(driver, exp_year);
    ElementsActions.clicker(driver, exp_year);
    return this;
}


public packagess option_exp_year() {
    Helper.waitForElement(driver, option_exp_year);
    ElementsActions.clicker(driver, option_exp_year);
    return this;
}

public packagess enterphoneNumber( String fieldName) throws IOException, ParseException {
    Helper.waitForElement(driver , phonenumber);
    ElementsActions.sendText(driver , phonenumber , fieldName);

    return this;
}
public packagess enter_sec_code( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , sec_code);
ElementsActions.sendText(driver , sec_code , fieldName);

return this;
}
public packagess enter_zip_code( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , zip_code);
ElementsActions.sendText(driver , zip_code , fieldName);

return this;
}
public packagess phoneCountryCode() {
    Helper.waitForElement(driver, phoneCountryCode);
    ElementsActions.clicker(driver, phoneCountryCode);
    return this;
}


public packagess option_phoneCountryCode() {
    Helper.waitForElement(driver, option_phoneCountryCode);
    ElementsActions.clicker(driver, option_phoneCountryCode);
    return this;
}

public packagess birth_month() {
    Helper.waitForElement(driver, birth_month);
    ElementsActions.clicker(driver, birth_month);
    return this;
}


public packagess option_birth_month() {
    Helper.waitForElement(driver, option_birth_month);
    ElementsActions.clicker(driver, option_birth_month);
    return this;
}

public packagess birth_day() {
    Helper.waitForElement(driver, birth_day);
    ElementsActions.clicker(driver, birth_day);
    return this;
}


public packagess option_birth_day() {
    Helper.waitForElement(driver, option_birth_day);
    ElementsActions.clicker(driver, option_birth_day);
    return this;
}

public packagess birth_year() {
    Helper.waitForElement(driver, birth_year);
    ElementsActions.clicker(driver,birth_year);
    return this;
}

public packagess option_birth_year() {
    Helper.waitForElement(driver, option_birth_year);
    ElementsActions.clicker(driver, option_birth_year);
    return this;
}

public packagess select_traveller() {
    Helper.waitForElement(driver, select_traveller);
    ElementsActions.clicker(driver, select_traveller);
    return this;
}


public packagess option_select_traveller() {
    Helper.waitForElement(driver, option_select_traveller);
    ElementsActions.clicker(driver, option_select_traveller);
    return this;
}
public packagess enter_traveller_first_name( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , traveller_first_name);
ElementsActions.sendText(driver , traveller_first_name , fieldName);

return this;
}
public packagess enter_traveller_last_name( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , traveller_last_name);
ElementsActions.sendText(driver , traveller_last_name , fieldName);

return this;
}

public packagess birth_month2() {
    Helper.waitForElement(driver, birth_month2);
    ElementsActions.clicker(driver, birth_month2);
    return this;
}


public packagess option_birth_month2() {
    Helper.waitForElement(driver, option_birth_month2);
    ElementsActions.clicker(driver, option_birth_month2);
    return this;
}

public packagess birth_day2() {
    Helper.waitForElement(driver, birth_day2);
    ElementsActions.clicker(driver, birth_day2);
    return this;
}


public packagess option_birth_day2() {
    Helper.waitForElement(driver, option_birth_day2);
    ElementsActions.clicker(driver, option_birth_day2);
    return this;
}

public packagess birth_year2() {
    Helper.waitForElement(driver, birth_year2);
    ElementsActions.clicker(driver,birth_year2);
    return this;
}


public packagess option_birth_year2() {
    Helper.waitForElement(driver, option_birth_year2);
    ElementsActions.clicker(driver, option_birth_year2);
    return this;
}
public packagess country() {
    Helper.waitForElement(driver, country);
    ElementsActions.clicker(driver,country);
    return this;
}


public packagess option_country() {
    Helper.waitForElement(driver, option_country);
    ElementsActions.clicker(driver, option_country);
    return this;
}
public packagess enter_billingAdress1( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , billingAdress1);
ElementsActions.sendText(driver , billingAdress1 , fieldName);

return this;
}
public packagess enter_billingAdress2( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , billingAdress2);
ElementsActions.sendText(driver , billingAdress2 , fieldName);

return this;
}
public packagess enter_city( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , city);
ElementsActions.sendText(driver , city , fieldName);

return this;
}
public packagess enter_state( String fieldName) throws IOException, ParseException {
Helper.waitForElement(driver , state);
ElementsActions.sendText(driver , state , fieldName);

return this;
}





   }

