package Pages.morethanScenario;
import Pages.Base.Browser;
import io.qameta.allure.Allure;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.Package.packagess;
import Pages.car.car;
import Pages.car.checkout_recommended_car;
import Pages.explore_trip.explore_trip;
import Pages.flight.flight;
import Pages.stays.book_StaysPage;
import Pages.stays.checkout_recommended_stays;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import java.io.IOException;
import java.util.Scanner;

public class login_with_carPage {
    private WebDriver driver;

    LoginPage loginPage;
    car carPage;
    checkout_recommended_stays checkoutpage;
    checkout_recommended_car checkout_carpage;
    flight flightPage;
    packagess packages;

    //contractor
    public login_with_carPage(WebDriver driver)
    {
        this.driver = driver;
    }
    public login_with_carPage() {
        // Default constructor
    }
    @DataProvider(name="login")
    public Object[][] getData() {
        return new Object[][] {
            // email,         password, should pass?
            {"mohamed_mamdouh@outlook.com", "MohamedMamdouh@12", true},
            {"not_user", "age1233", false},
            {"", "age1233", false},
            {"not_user", "", false},
            {"", "", false}
        };
    }

    @Test(dataProvider="login", dataProviderClass = login_with_carPage.class)
    public void login(String usernameEmail, String password, boolean shouldSucceed) throws InterruptedException, IOException, ParseException {
    	
    	System.out.println("Email: " + usernameEmail);
        System.out.println("Password: " + password);
        System.out.println("Should Succeed: " + shouldSucceed);
        
    	loginPage = new LoginPage(driver);
    	carPage = new car(driver);
    	checkoutpage=new checkout_recommended_stays(driver);
    	checkout_carpage=new checkout_recommended_car(driver);
        packages=new packagess(driver);

    	loginPage.enterTheEmailAddress(usernameEmail);
        Helper.wait_(1);
   
        loginPage.enterPassword(password);
        Helper.wait_(1);


       
        if (shouldSucceed==true) {
        	loginPage.clickOnLoginButton();    
        	  System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
        	    Scanner scanner = new Scanner(System.in);
        	    scanner.nextLine(); // ينتظر إدخال المستخدم
        	
        	carPage.car_button();
        	Helper.wait_(2);

        	carPage.leave_from();
        	Helper.wait_(1);
        	carPage.leave_from_city("Downtown Cairo, Cairo, Cairo Governorate, Egypt");
        	Helper.wait_(1);
        	carPage.select_city();

        	carPage.going_to();
        	Helper.wait_(1);
        	carPage.going_to_city("Nasr City, Cairo, Cairo Governorate, Egypt");
        	Helper.wait_(1);

        //	carPage.clickOndates();
//        	Helper.wait_(1);
//        	carPage.clickOnchoose_done();
//        	
//        	Helper.wait_(1);
        	
        	carPage.pick_up_time();
        	Helper.wait_(1);
        	carPage.option01();
        	
        	carPage.drop_off_time();
        	Helper.wait_(1);
        	carPage.option02();

        	carPage.clickOnsearch_button();
        	Helper.wait_(1);

        	carPage.rserve_car();
        	Helper.wait_(1);
        	
        	Browser.return_to_Tab(1);
     	    carPage.rserve_car2();
     	    
        	Helper.wait_(3);
        	
        	checkout_carpage.phoneCountryCode();
        	checkout_carpage.option_phoneCountryCode();
        	checkout_carpage.enterphoneNumber("01118712681");
        	Helper.wait_(2);
        	//checkoutpage.dropdownLocator_by();
//        	checkoutpage.egyptOptionLocator_by();
        	checkout_carpage.select_protection_yes();
        	Helper.wait_(2);
        //	checkoutpage.enter_usercardName("mohamed123");

        	checkout_carpage.enter_usercardNumber("0239291120313");
        	
        	checkout_carpage.exp_month();
        	checkout_carpage.option_exp_month();
        	Helper.wait_(1);
        	
        	checkout_carpage.exp_year();
        	checkout_carpage.option_exp_year();
        	Helper.wait_(1);

        	checkout_carpage.enter_sec_code("334");
        	Helper.wait_(1);
        	checkout_carpage.enter_zip_code("12511");

        	checkout_carpage.ReserveNow();
        	packages.remember_card();

        	  System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
      	    scanner.nextLine(); // ينتظر إدخال المستخدم

        	Helper.wait_(3);

            String actualResult =   Browser.getUrl();
            String expectedResult = "https://www.travelocity.com/";

            assertNotEquals(expectedResult, actualResult);
            
         

        }
         if (shouldSucceed=false) {
        	loginPage.disableLoginButton();
        	Helper.wait_(2);
        	
            WebElement element = driver.findElement(By.tagName("h1"));
            String actualResult = element.getText();
            
            String expectedResult = "Sign in";

            assertEquals(expectedResult, actualResult);
        }
    
        
        
        
        
        
       
    }

  
}