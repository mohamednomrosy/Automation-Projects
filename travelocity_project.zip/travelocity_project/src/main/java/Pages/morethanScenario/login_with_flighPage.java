package Pages.morethanScenario;
import Pages.Base.Browser;
import io.qameta.allure.Allure;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.Package.packagess;
import Pages.explore_trip.explore_trip;
import Pages.flight.flight;
import Pages.stays.book_StaysPage;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import java.io.IOException;
import java.util.Scanner;

public class login_with_flighPage {
    private WebDriver driver;

    LoginPage loginPage;
    flight flightPage;
    explore_trip explore_trippage;
    packagess packages;

    //contractor
    public login_with_flighPage(WebDriver driver)
    {
        this.driver = driver;
    }
    public login_with_flighPage() {
        // Default constructor
    }
    @DataProvider(name="login")
    public Object[][] getData() {
        return new Object[][] {
            // email,         password, should pass?
            {"mohamed_mamdouh@outlook.com", "MohamedMamdouh@12", true},
//            {"not_user", "age1233", false},
//            {"", "age1233", false},
//            {"not_user", "", false},
//            {"", "", false}
        };
    }

    @Test(dataProvider="login", dataProviderClass = login_with_flighPage.class)
    public void login(String usernameEmail, String password, boolean shouldSucceed) throws InterruptedException, IOException, ParseException {
    	
    	System.out.println("Email: " + usernameEmail);
        System.out.println("Password: " + password);
        System.out.println("Should Succeed: " + shouldSucceed);
        
    	loginPage = new LoginPage(driver);
    	flightPage = new flight(driver);
    	explore_trippage=new explore_trip(driver);
    	packages = new packagess(driver);

    	loginPage.enterTheEmailAddress(usernameEmail);
        Helper.wait_(1);
   
        loginPage.enterPassword(password);
        Helper.wait_(1);

//        String Baseurl = Browser.getUrl();
//        String url = "";
       
        if (shouldSucceed==true) {
        	loginPage.clickOnLoginButton();    
        	  System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
        	    Scanner scanner = new Scanner(System.in);
        	    scanner.nextLine(); // ينتظر إدخال المستخدم
        	
        	flightPage.flight_button();
        	Helper.wait_(2);

        	flightPage.leave_from();
        	Helper.wait_(1);
        	flightPage.leave_from_city("San Francisco, CA, United States of America (SFO-San Francisco Intl.)");
        	Helper.wait_(1);
        	flightPage.select_city();

        	flightPage.going_to();
        	Helper.wait_(1);
        	flightPage.going_to_city("Detroit, MI, United States of America (DTW-Detroit Metropolitan Wayne County)");
        	Helper.wait_(1);
        	flightPage.select2_city();

        	flightPage.clickOndates();
        	Helper.wait_(1);
        	flightPage.clickOnchoose_done();
        	
        	
        	Helper.wait_(1);

        	flightPage.clickOntravelers();
        	Helper.wait_(1);

        	flightPage.clickOnadults();
        	Helper.wait_(1);
        	
        	flightPage.clickOnsearch_button();
    		
        	 System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
     	    scanner.nextLine(); // ينتظر إدخال 
     	    
        	Helper.wait_(3);
     	    explore_trippage.scrollPage();
     	    
        	flightPage.depart_time();
        	Helper.wait_(4);

        	flightPage.select_fare();
        	Helper.wait_(2);

        	flightPage.return_time();
        	Helper.wait_(4);

        	flightPage.select_fare2();
        	Helper.wait_(2);
        	
        	flightPage.no_thanks();
        	
        	Browser.return_to_Tab(1);

     	    explore_trippage.scrollPage();
        	flightPage.checkout();
        	flightPage.Go_to_checkout();
        	Helper.wait_(2);
        	
        	flightPage.phoneCountryCode();
        	flightPage.option_phoneCountryCode();
        	flightPage.enterphoneNumber("01118712681");
        	Helper.wait_(2);
        	flightPage.gender();
        	
        	flightPage.birth_month();
        	flightPage.option_birth_month();
        	
        	flightPage.birth_day();
        	flightPage.option_birth_day();
        	
        	flightPage.birth_year();
        	flightPage.option_birth_year();
        	
        	packages.car_protection();

        	packages.enter_usercardNumber("0239291120313");
        	
        	packages.exp_month();
        	packages.option_exp_month();
        	Helper.wait_(1);
        	
        	packages.exp_year();
        	packages.option_exp_year();
        	Helper.wait_(1);

        	packages.enter_sec_code("334");
        	Helper.wait_(1);
        	
        	packages.country();
        	packages.option_country();
        	
        	packages.enter_billingAdress1("agakddq123");
        	Helper.wait_(1);

        	packages.enter_billingAdress2("alskdp230");
        	Helper.wait_(1);

        	packages.enter_city("morano");
        	
        	packages.enter_state("AL");
        	Helper.wait_(1);

        	packages.enter_zip_code("12511");
        	packages.remember_card();


            String actualResult =   Browser.getUrl();
            String expectedResult = "https://www.travelocity.com/";

            assertNotEquals(expectedResult, actualResult);
            
         

        }
         if (shouldSucceed=false) {
        	loginPage.disableLoginButton();
        	Helper.wait_(2);
        	
            WebElement element = driver.findElement(By.tagName("h1"));
            String actualResult = element.getText();
            
            String expectedResult = "Sign in";

            assertEquals(expectedResult, actualResult);
        }
    
        
        
        
        
        
       
    }

  
}