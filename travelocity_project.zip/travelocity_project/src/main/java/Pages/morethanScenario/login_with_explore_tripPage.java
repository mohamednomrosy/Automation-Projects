package Pages.morethanScenario;
import Pages.Base.Browser;
import io.qameta.allure.Allure;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.explore_trip.explore_trip;
import Pages.stays.book_StaysPage;
import Pages.stays.checkout_recommended_stays;
import Pages.stays.recommended_Stays;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import java.io.IOException;
import java.util.Scanner;

public class login_with_explore_tripPage {
    private WebDriver driver;

    LoginPage loginPage;
    recommended_Stays staysPage;
    checkout_recommended_stays checkoutpage;
    explore_trip explore_trippage;
    //contractor
    public login_with_explore_tripPage(WebDriver driver)
    {
        this.driver = driver;
    }
    public login_with_explore_tripPage() {
        // Default constructor
    }
    @DataProvider(name="login")
    public Object[][] getData() {
        return new Object[][] {
            // email,         password, should pass?
            {"mohamed_mamdouh@outlook.com", "MohamedMamdouh@12", true},
//            {"not_user", "age1233", false},
//            {"", "age1233", false},
//            {"not_user", "", false},
//            {"", "", false}
        };
    }

    @Test(dataProvider="login", dataProviderClass = login_with_explore_tripPage.class)
    public void login(String usernameEmail, String password, boolean shouldSucceed) throws InterruptedException, IOException, ParseException {
    	
    	System.out.println("Email: " + usernameEmail);
        System.out.println("Password: " + password);
        System.out.println("Should Succeed: " + shouldSucceed);
        
    	loginPage = new LoginPage(driver);
    	explore_trippage=new explore_trip(driver);
    	loginPage.enterTheEmailAddress(usernameEmail);
        Helper.wait_(1);
   
        loginPage.enterPassword(password);
        Helper.wait_(1);

//        String Baseurl = Browser.getUrl();
//        String url = "";
       
        if (shouldSucceed==true) {
        	loginPage.clickOnLoginButton();    
        	  System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
        	    Scanner scanner = new Scanner(System.in);
        	    scanner.nextLine(); // ينتظر إدخال المستخدم
        	
    			
            	Helper.wait_(2);
                  // Perform scrolling and button test
            	
              explore_trippage.scroll_And_find_trip_button();
              Browser.return_to_Tab(1);
              Helper.wait_(2);
              System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
        	  scanner.nextLine(); // ينتظر إدخال 	
          	  explore_trippage.scrollPage();
          	  
          	  Browser.return_to_Tab(0);
          	  Helper.wait_(2);
          	  
              explore_trippage.book_flexibility_button();
          	  Browser.return_to_Tab(2);
          	  Helper.wait_(2);
              System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
        	  scanner.nextLine(); // ينتظر إدخال 	
          	  explore_trippage.scrollPage();
          	  
          	  Browser.return_to_Tab(0);
          	  Helper.wait_(2);
          	  
              explore_trippage.got_yourBack_button();
          	  Browser.return_to_Tab(3);
          	  Helper.wait_(2);
              System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
        	  scanner.nextLine(); // ينتظر إدخال 	
          	  explore_trippage.scrollPage();
          	  
          	  
          	  Browser.return_to_Tab(0);
          	  Helper.wait_(2);
          	  
              explore_trippage.inclusiveResorts_button();
          	  Helper.wait_(2);
          	  explore_trippage.scrollPage();
          	  
			  Browser.back();
			  Helper.wait_(2);

              explore_trippage.lastMinute_button();
          	  Helper.wait_(2);	
          	  explore_trippage.scrollPage();
          	  
			  Browser.back();
			  Helper.wait_(2);
          	  
              explore_trippage.start_Plan_Sunny_offer_button();
          	  Helper.wait_(2);
          	  explore_trippage.scrollPage();
          	  
			  Browser.back();
			  Helper.wait_(2);
          	  
//              explore_trippage.start_Plan_Car_rental_button();
//          	  Helper.wait_(2);
//          	  explore_trippage.scrollPage();
//          	  
//			  Browser.back();
//			  Helper.wait_(2);
          	  
              explore_trippage.start_Plan_Member_disc_button();
          	  Helper.wait_(2);
          	  explore_trippage.scrollPage();
          	  
//			  Browser.back();
//			  Helper.wait_(2);
//          	  
//              explore_trippage.start_Plan_vacation_rental_button();
//          	  Helper.wait_(2);
//          	  explore_trippage.scrollPage();
          	  
			  Browser.back();
			  Helper.wait_(2);
          	  
              explore_trippage.change_cancel_trip_button();
          	  Helper.wait_(3);
          	            	  
              explore_trippage.use_credit_Coupon_button();
          	  Helper.wait_(2);
          	  explore_trippage.scrollPage();
          	  
			  Browser.back();
			  Helper.wait_(3);
          	  
      	  Browser.return_to_Tab(1);



            String actualResult =   Browser.getUrl();
            String expectedResult = "https://www.travelocity.com/";

            assertNotEquals(expectedResult, actualResult);
            
         

        }
         if (shouldSucceed=false) {
        	loginPage.disableLoginButton();
        	Helper.wait_(2);
        	
            WebElement element = driver.findElement(By.tagName("h1"));
            String actualResult = element.getText();
            
            String expectedResult = "Sign in";

            assertEquals(expectedResult, actualResult);
        }
    
        
        
        
        
        
       
    }

  
}