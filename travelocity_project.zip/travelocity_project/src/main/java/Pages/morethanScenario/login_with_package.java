package Pages.morethanScenario;
import Pages.Base.Browser;
import io.qameta.allure.Allure;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.Package.packagess;
import Pages.car.car;
import Pages.car.checkout_recommended_car;
import Pages.explore_trip.explore_trip;
import Pages.flight.flight;
import Pages.stays.book_StaysPage;
import Pages.stays.checkout_recommended_stays;
import Pages.stays.recommended_Stays;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import java.io.IOException;
import java.util.Scanner;

public class login_with_package {
    private WebDriver driver;

    LoginPage loginPage;
    car carPage;
    recommended_Stays staysPage;
    checkout_recommended_stays checkoutpage;
    checkout_recommended_car checkout_carpage;
    packagess packages;
    flight flightPage;
    explore_trip explore_trippage;
    //contractor
    public login_with_package(WebDriver driver)
    {
        this.driver = driver;
    }
    public login_with_package() {
        // Default constructor
    }
    @DataProvider(name="login")
    public Object[][] getData() {
        return new Object[][] {
            // email,         password, should pass?
            {"mohamed_mamdouh@outlook.com", "MohamedMamdouh@12", true},
            {"not_user", "age1233", false},
            {"", "age1233", false},
            {"not_user", "", false},
            {"", "", false}
        };
    }

    @Test(dataProvider="login", dataProviderClass = login_with_package.class)
    public void login(String usernameEmail, String password, boolean shouldSucceed) throws InterruptedException, IOException, ParseException {
    	
    	System.out.println("Email: " + usernameEmail);
        System.out.println("Password: " + password);
        System.out.println("Should Succeed: " + shouldSucceed);
        
    	loginPage = new LoginPage(driver);
    	carPage = new car(driver);
    	checkoutpage=new checkout_recommended_stays(driver);
    	checkout_carpage=new checkout_recommended_car(driver);
    	flightPage = new flight(driver);
    	explore_trippage=new explore_trip(driver);
        staysPage=new recommended_Stays(driver);
        packages=new packagess(driver);
        
    	loginPage.enterTheEmailAddress(usernameEmail);
        Helper.wait_(1);
   
        loginPage.enterPassword(password);
        Helper.wait_(1);

//        String Baseurl = Browser.getUrl();
//        String url = "";
       
        if (shouldSucceed==true) {
        	loginPage.clickOnLoginButton();    
        	  System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
        	    Scanner scanner = new Scanner(System.in);
        	    scanner.nextLine(); // ينتظر إدخال المستخدم
        	
            packages.package_button();
        	Helper.wait_(1);
        	
            packages.car_button();
        	Helper.wait_(1);
        	
        	flightPage.leave_from();
        	Helper.wait_(1);
        	flightPage.leave_from_city("San Francisco, CA, United States of America (SFO-San Francisco Intl.)");
        	Helper.wait_(1);
        	flightPage.select_city();

        	flightPage.going_to();
        	Helper.wait_(1);
        	flightPage.going_to_city("Detroit, MI, United States of America (DTW-Detroit Metropolitan Wayne County)");
        	Helper.wait_(1);
        	flightPage.select2_city();

        	packages.clickOndates();
        	Helper.wait_(1);
        	packages.clickOnchoose_done();
        	
        	
        	Helper.wait_(1);

        	packages.clickOntravelers();
        	Helper.wait_(1);

        	
        	flightPage.clickOnsearch_button();
    		
        	
        	staysPage.open_sort_by();
        	Helper.wait_(1);
        	
        	staysPage.selectOptionValue3();
        	packages.chosse_filters_first();
        	
        	Browser.return_to_Tab(1);
        	
        	packages.select_room();
        	Helper.wait_(1);
//        	packages.close_room_classification();
//        	packages.reserve();
        	
        	packages.depart_time();
        	Helper.wait_(4);

        	packages.select_fare();
        	Helper.wait_(2);

        	packages.return_time();
        	Helper.wait_(4);

        	packages.select_fare2();
        	Helper.wait_(2);
        	
        	packages.rserve_car();
        	Helper.wait_(1);
        	
        	Helper.wait_(3);
        	
        	packages.phoneCountryCode();
        	packages.option_phoneCountryCode();
        	packages.enterphoneNumber("01118712681");
        	Helper.wait_(2);
        	packages.gender();
        	
        	packages.birth_month();
        	packages.option_birth_month();
        	
        	packages.birth_day();
        	packages.option_birth_day();
        	
        	packages.birth_year();
        	packages.option_birth_year();
        	
//        	packages.select_traveller();
//        	packages.option_select_traveller();
//
//        	packages.enter_traveller_first_name("Mona");
//        	packages.enter_traveller_last_name("Amr");
//
//        	packages.gender2();
//        	
//        	packages.birth_month2();
//        	packages.option_birth_month2();
//        	
//        	packages.birth_day2();
//        	packages.option_birth_day2();
//        	
//        	packages.birth_year2();
//        	packages.option_birth_year2();
        	
        	packages.trip_protection();
        	packages.car_protection();

        	packages.enter_usercardNumber("0239291120313");
        	
        	packages.exp_month();
        	packages.option_exp_month();
        	Helper.wait_(1);
        	
        	packages.exp_year();
        	packages.option_exp_year();
        	Helper.wait_(1);

        	packages.enter_sec_code("334");
        	Helper.wait_(1);
        	
        	packages.country();
        	packages.option_country();
        	
        	packages.enter_billingAdress1("agakddq123");
        	Helper.wait_(1);

        	packages.enter_billingAdress2("alskdp230");
        	Helper.wait_(1);

        	packages.enter_city("morano");
        	
        	packages.enter_state("AL");
        	Helper.wait_(1);

        	packages.enter_zip_code("12511");
        	packages.remember_card();

//        	Helper.wait_(2);
        //	checkoutpage.enter_usercardName("mohamed123");

//        	packages.enter_usercardNumber("0239291120313");
//        	
//        	packages.exp_month();
//        	packages.option_exp_month();
//        	Helper.wait_(1);
//        	
//        	packages.exp_year();
//        	packages.option_exp_year();
//        	Helper.wait_(1);
//
//        	packages.enter_sec_code("334");
//        	Helper.wait_(1);
//        	packages.enter_zip_code("12511");
//        	
        	 System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
     	    scanner.nextLine(); // ينتظر إدخال 
        	
        	
        	
        	
        	
        	
        	
//        	staysPage.clickOnwhere_to();
//        	Helper.wait_(1);
//
//        	staysPage.Choose_destination();
//        	Helper.wait_(1);
//
//        	staysPage.clickOndates();
//        	Helper.wait_(1);
//
//        	staysPage.clickOnchoose_done();
//        	Helper.wait_(1);
//
//        	staysPage.clickOntravelers();
//        	Helper.wait_(1);
//
//        	staysPage.clickOnadults();
//        	Helper.wait_(1);
//
//        	staysPage.clickOnchildrens();
//        	Helper.wait_(1);
//        	
//        	staysPage.openDropdownList();
//        	Helper.wait_(1);
//        	
//        	staysPage.selectOptionValue();
//        	Helper.wait_(1);
//
//        	staysPage.clickOnanother_room();
//        	Helper.wait_(1);
//        	
//        	staysPage.clickOnadults2();
//        	Helper.wait_(1);
//
//        	staysPage.clickOnchildrens2();
//        	Helper.wait_(1);
//        	
//        	staysPage.openDropdownList2();
//        	Helper.wait_(1);
//        	
//        	staysPage.selectOptionValue2();
//        	Helper.wait_(1);
//        	
//			staysPage.clickOnchoose_done2();
//			Helper.wait_(3);
//
//    		staysPage.clickOnsearch_button();
        	
            String actualResult =   Browser.getUrl();
            String expectedResult = "https://www.travelocity.com/";

            assertNotEquals(expectedResult, actualResult);
            
         

        }
         if (shouldSucceed=false) {
        	loginPage.disableLoginButton();
        	Helper.wait_(2);
        	
            WebElement element = driver.findElement(By.tagName("h1"));
            String actualResult = element.getText();
            
            String expectedResult = "Sign in";

            assertEquals(expectedResult, actualResult);
        }
    
        
        
        
        
        
       
    }

  
}