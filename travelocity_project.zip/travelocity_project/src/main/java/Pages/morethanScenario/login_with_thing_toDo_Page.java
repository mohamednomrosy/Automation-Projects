package Pages.morethanScenario;
import Pages.Base.Browser;
import io.qameta.allure.Allure;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.Package.packagess;
import Pages.stays.book_StaysPage;
import Pages.thing_toDo.thing_toDo;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import java.io.IOException;
import java.util.Scanner;

public class login_with_thing_toDo_Page {
    private WebDriver driver;

    LoginPage loginPage;
    thing_toDo thingPage;
    packagess packages;
    //contractor
    public login_with_thing_toDo_Page(WebDriver driver)
    {
        this.driver = driver;
    }
    public login_with_thing_toDo_Page() {
        // Default constructor
    }
    @DataProvider(name="login")
    public Object[][] getData() {
        return new Object[][] {
            // email,         password, should pass?
            {"mohamed_mamdouh@outlook.com", "MohamedMamdouh@12", true},
//            {"not_user", "age1233", false},
//            {"", "age1233", false},
//            {"not_user", "", false},
//            {"", "", false}
        };
    }

    @Test(dataProvider="login", dataProviderClass = login_with_thing_toDo_Page.class)
    public void login(String usernameEmail, String password, boolean shouldSucceed) throws InterruptedException, IOException, ParseException {
    	
    	System.out.println("Email: " + usernameEmail);
        System.out.println("Password: " + password);
        System.out.println("Should Succeed: " + shouldSucceed);
        
    	loginPage = new LoginPage(driver);
    	thingPage = new thing_toDo(driver);
    	loginPage.enterTheEmailAddress(usernameEmail);
        packages=new packagess(driver);
        Helper.wait_(1);
   
        loginPage.enterPassword(password);
        Helper.wait_(1);

//        String Baseurl = Browser.getUrl();
//        String url = "";
       
        if (shouldSucceed==true) {
        	loginPage.clickOnLoginButton();    
        	  System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
        	    Scanner scanner = new Scanner(System.in);
        	    scanner.nextLine(); // ينتظر إدخال المستخدم
        	
        	thingPage.thing_toDo_button();
            Helper.wait_(1);
            thingPage.going_to();
            thingPage.going_to_city("Alexandria (and vicinity), Alexandria Governorate, Egypt");
//            thingPage.going_to_city2();
            Helper.wait_(1);
        	
            thingPage.clickOndates();
        	Helper.wait_(1);

        	thingPage.clickOnchoose_done();
        	Helper.wait_(1);
        	
        	thingPage.clickOnsearch_button();
        	
        	thingPage.search_alex("Alexandria");

            Helper.wait_(5);

        	thingPage.alex_tour2();
        	Browser.return_to_Tab(1);
        	Helper.wait_(2);
        	thingPage.book_alex_tour2();
        	Helper.wait_(2);
        	Browser.return_to_Tab(0);
        	
        	thingPage.alex_tour3();
        	Browser.return_to_Tab(2);
        	Helper.wait_(2);
        	thingPage.book_alex_tour3();
        	Helper.wait_(2);
        	Browser.return_to_Tab(0);
        	
        	thingPage.alex_tour4();
        	Browser.return_to_Tab(3);
        	Helper.wait_(2);
        	thingPage.book_alex_tour4();
        	Helper.wait_(2);
        	Browser.return_to_Tab(0);
        	
        	thingPage.alex_tour5();
        	Browser.return_to_Tab(4);
        	Helper.wait_(2);
        	thingPage.book_alex_tour5();
        	Helper.wait_(2);
        	Browser.return_to_Tab(0);
        	
        	Helper.wait_(2);
        	thingPage.see_all_alex_tours();
        	
        	thingPage.alex_tour6();
        	Browser.return_to_Tab(5);
        	Helper.wait_(2);
        	thingPage.book_alex_tour6();
        	Helper.wait_(2);
        	Browser.return_to_Tab(0);

    	    scanner.nextLine(); // ينتظر إدخال المستخدم

            String actualResult =   Browser.getUrl();
            String expectedResult = "https://www.travelocity.com/";

            assertNotEquals(expectedResult, actualResult);
            
         

        }
         if (shouldSucceed=false) {
        	loginPage.disableLoginButton();
        	Helper.wait_(2);
        	
            WebElement element = driver.findElement(By.tagName("h1"));
            String actualResult = element.getText();
            
            String expectedResult = "Sign in";

            assertEquals(expectedResult, actualResult);
        }
    
        
        
        
        
        
       
    }

  
}