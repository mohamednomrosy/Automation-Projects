package Pages.morethanScenario;
import Pages.Base.Browser;
import io.qameta.allure.Allure;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.Package.packagess;
import Pages.stays.book_StaysPage;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import java.io.IOException;
import java.util.Scanner;

public class login_with_book_StaysPage {
    private WebDriver driver;

    LoginPage loginPage;
    book_StaysPage staysPage;
    packagess packages;
    //contractor
    public login_with_book_StaysPage(WebDriver driver)
    {
        this.driver = driver;
    }
    public login_with_book_StaysPage() {
        // Default constructor
    }
    @DataProvider(name="login")
    public Object[][] getData() {
        return new Object[][] {
            // email,         password, should pass?
            {"mohamed_mamdouh@outlook.com", "MohamedMamdouh@12", true},
            {"not_user", "age1233", false},
            {"", "age1233", false},
            {"not_user", "", false},
            {"", "", false}
        };
    }

    @Test(dataProvider="login", dataProviderClass = login_with_book_StaysPage.class)
    public void login(String usernameEmail, String password, boolean shouldSucceed) throws InterruptedException, IOException, ParseException {
    	
    	System.out.println("Email: " + usernameEmail);
        System.out.println("Password: " + password);
        System.out.println("Should Succeed: " + shouldSucceed);
        
    	loginPage = new LoginPage(driver);
    	staysPage = new book_StaysPage(driver);
    	loginPage.enterTheEmailAddress(usernameEmail);
        packages=new packagess(driver);
        Helper.wait_(1);
   
        loginPage.enterPassword(password);
        Helper.wait_(1);
       
        if (shouldSucceed==true) {
        	loginPage.clickOnLoginButton();    
        	  System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
        	    Scanner scanner = new Scanner(System.in);
        	    scanner.nextLine(); // ينتظر إدخال المستخدم
        	
        	staysPage.clickOnwhere_to("Alexandria (and vicinity), Alexandria Governorate, Egypt\r\n"
        			+ "");
        	Helper.wait_(1);


        	staysPage.clickOndates();
        	Helper.wait_(1);

        	staysPage.clickOnchoose_done();
        	Helper.wait_(1);

        	staysPage.clickOntravelers();
        	Helper.wait_(1);

        	staysPage.clickOnadults();
        	Helper.wait_(1);

        	staysPage.clickOnchildrens();
        	Helper.wait_(1);
        	
        	staysPage.openDropdownList();
        	Helper.wait_(1);
        	
        	staysPage.selectOptionValue();
        	Helper.wait_(1);

        	staysPage.clickOnanother_room();
        	Helper.wait_(1);
        	
        	staysPage.clickOnadults2();
        	Helper.wait_(1);

        	staysPage.clickOnchildrens2();
        	Helper.wait_(1);
        	
        	staysPage.openDropdownList2();
        	Helper.wait_(1);
        	
        	staysPage.selectOptionValue2();
        	Helper.wait_(1);
        	
			staysPage.clickOnchoose_done2();
			Helper.wait_(3);

    		staysPage.clickOnsearch_button();
    		
    		staysPage.select_room();
    		
        	Browser.return_to_Tab(1);

        	Helper.wait_(1);
        	staysPage.chosse_room_classification();
        	staysPage.close_room_classification();
        	staysPage.reserve();
        	staysPage.payNow();

        	packages.enter_usercardNumber("0239291120313");
        	packages.exp_month();
        	packages.option_exp_month();
        	Helper.wait_(1);
        	
        	packages.exp_year();
        	packages.option_exp_year();
        	Helper.wait_(1);

        	packages.enter_sec_code("334");
        	Helper.wait_(1);
        	packages.enter_zip_code("12511");
        	packages.remember_card();

    	    scanner.nextLine(); // ينتظر إدخال المستخدم

        	
            String actualResult =   Browser.getUrl();
            String expectedResult = "https://www.travelocity.com/";

            assertNotEquals(expectedResult, actualResult);
            
         

        }
         if (shouldSucceed=false) {
        	loginPage.disableLoginButton();
        	Helper.wait_(2);
        	
            WebElement element = driver.findElement(By.tagName("h1"));
            String actualResult = element.getText();
            
            String expectedResult = "Sign in";

            assertEquals(expectedResult, actualResult);
        }
    
        
        
        
        
        
       
    }

  
}