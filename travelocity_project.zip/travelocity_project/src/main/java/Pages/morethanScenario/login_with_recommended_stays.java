package Pages.morethanScenario;
import Pages.Base.Browser;
import io.qameta.allure.Allure;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.stays.book_StaysPage;
import Pages.stays.checkout_recommended_stays;
import Pages.stays.recommended_Stays;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import java.io.IOException;
import java.util.Scanner;

public class login_with_recommended_stays {
    private WebDriver driver;

    LoginPage loginPage;
    recommended_Stays staysPage;
    checkout_recommended_stays checkoutpage;
    //contractor
    public login_with_recommended_stays(WebDriver driver)
    {
        this.driver = driver;
    }
    public login_with_recommended_stays() {
        // Default constructor
    }
    @DataProvider(name="login")
    public Object[][] getData() {
        return new Object[][] {
            // email,         password, should pass?
            {"mohamed_mamdouh@outlook.com", "MohamedMamdouh@12", true},
            {"not_user", "age1233", false},
            {"", "age1233", false},
            {"not_user", "", false},
            {"", "", false}
        };
    }

    @Test(dataProvider="login", dataProviderClass = login_with_recommended_stays.class)
    public void login(String usernameEmail, String password, boolean shouldSucceed) throws InterruptedException, IOException, ParseException {
    	
    	System.out.println("Email: " + usernameEmail);
        System.out.println("Password: " + password);
        System.out.println("Should Succeed: " + shouldSucceed);
        
    	loginPage = new LoginPage(driver);
    	staysPage = new recommended_Stays(driver);
    	checkoutpage=new checkout_recommended_stays(driver);
    	loginPage.enterTheEmailAddress(usernameEmail);
        Helper.wait_(1);
   
        loginPage.enterPassword(password);
        Helper.wait_(1);

//        String Baseurl = Browser.getUrl();
//        String url = "";
       
        if (shouldSucceed==true) {
        	loginPage.clickOnLoginButton();    
        	  System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
        	    Scanner scanner = new Scanner(System.in);
        	    scanner.nextLine(); // ينتظر إدخال المستخدم
        	
    			staysPage.clickOnexplorestays(); 
            	Helper.wait_(4);
            	
            	Browser.return_to_Tab(1);
    	
                staysPage.enterTheminPrice("100");
                staysPage.enterThemaxPrice("200");
                
            	staysPage.open_sort_by();
            	Helper.wait_(1);
            	
            	staysPage.selectOptionValue3();
            	staysPage.chosse_filters_first();

            	Helper.wait_(6);
            	
            	Browser.return_to_Tab(2);
            	
            	staysPage.select_room();
            	Helper.wait_(1);
            	staysPage.chosse_room_classification();
            	staysPage.close_room_classification();
            	staysPage.reserve();
            	staysPage.payNow();

            	//Browser.openNewTab(3);


            	checkoutpage.enterphoneNumber("01118712681");
            	Helper.wait_(2);

            	checkoutpage.select_protection_yes();
            	Helper.wait_(2);
            	checkoutpage.enter_usercardNumber("0239291120313");
            	
            	checkoutpage.exp_month();
            	checkoutpage.option_exp_month();
            	Helper.wait_(1);
            	
            	checkoutpage.exp_year();
            	checkoutpage.option_exp_year();
            	Helper.wait_(1);

            	checkoutpage.enter_sec_code("334");
            	Helper.wait_(1);
            	checkoutpage.enter_zip_code("12511");

            	Helper.wait_(3);

        	
            String actualResult =   Browser.getUrl();
            String expectedResult = "https://www.travelocity.com/";

            assertNotEquals(expectedResult, actualResult);
            
         

        }
         if (shouldSucceed=false) {
        	loginPage.disableLoginButton();
        	Helper.wait_(2);
        	
            WebElement element = driver.findElement(By.tagName("h1"));
            String actualResult = element.getText();
            
            String expectedResult = "Sign in";

            assertEquals(expectedResult, actualResult);
        }
    
        
        
        
        
        
       
    }

  
}