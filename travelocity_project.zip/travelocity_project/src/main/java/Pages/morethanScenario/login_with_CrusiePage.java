package Pages.morethanScenario;
import Pages.Base.Browser;
import io.qameta.allure.Allure;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.Package.packagess;
import Pages.cruise.cruise;
import Pages.stays.book_StaysPage;
import Pages.thing_toDo.thing_toDo;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import java.io.IOException;
import java.util.Scanner;

public class login_with_CrusiePage {
    private WebDriver driver;

    LoginPage loginPage;
    thing_toDo thingPage;
    packagess packages;
    cruise cruises;
    //contractor
    public login_with_CrusiePage(WebDriver driver)
    {
        this.driver = driver;
    }
    public login_with_CrusiePage() {
        // Default constructor
    }
    @DataProvider(name="login")
    public Object[][] getData() {
        return new Object[][] {
            // email,         password, should pass?
            {"mohamed_mamdouh@outlook.com", "MohamedMamdouh@12", true},
            {"not_user", "age1233", false},
            {"", "age1233", false},
            {"not_user", "", false},
            {"", "", false}
        };
    }

    @Test(dataProvider="login", dataProviderClass = login_with_CrusiePage.class)
    public void login(String usernameEmail, String password, boolean shouldSucceed) throws InterruptedException, IOException, ParseException {
    	
    	System.out.println("Email: " + usernameEmail);
        System.out.println("Password: " + password);
        System.out.println("Should Succeed: " + shouldSucceed);
        
    	loginPage = new LoginPage(driver);
    	thingPage = new thing_toDo(driver);
    	loginPage.enterTheEmailAddress(usernameEmail);
        packages=new packagess(driver);
        cruises=new cruise(driver);
        Helper.wait_(1);
   
        loginPage.enterPassword(password);
        Helper.wait_(1);

//        String Baseurl = Browser.getUrl();
//        String url = "";
       
        if (shouldSucceed==true) {
        	loginPage.clickOnLoginButton();    
        	  System.out.println("CAPTCHA is visible. Please solve it manually and press Enter to continue.");
        	    Scanner scanner = new Scanner(System.in);
        	    scanner.nextLine(); // ينتظر إدخال المستخدم
        	
        	cruises.cruise_button();
            Helper.wait_(1);
            cruises.going_to();
            Helper.wait_(1);
            cruises.going_to_city("europe");
//            Helper.wait_(1);
//            cruises.europe();
        	Helper.wait_(1);
        	
        	cruises.clickOndates();
        	Helper.wait_(1);
        	cruises.clickOnchoose_done();
        	Helper.wait_(1);
        	
        	cruises.duration();
        	Helper.wait_(1);
        	cruises.min_duration("2");
        	Helper.wait_(1);
        	cruises.max_duration("6");
        	Helper.wait_(1);
        	cruises.clickOnchoose_done2();
        	Helper.wait_(1);

        	cruises.traveller();
        	Helper.wait_(1);
        	cruises.decrease_adult();
        	Helper.wait_(1);
        	cruises.increase_child();
        	Helper.wait_(1);
        	cruises.select_age_travelers();
        	Helper.wait_(1);
        	cruises.option_age_5();   
        	Helper.wait_(1);
        	cruises.clickOnchoose_done3();
        	Helper.wait_(1);

        	thingPage.clickOnsearch_button();
        	
        	cruises.cruise_line1();
        	Helper.wait_(1);
        	
        	cruises.cruise_line2();
        	Helper.wait_(1);
        	
        	cruises.cruise_line3();
        	Helper.wait_(1);
        	
//        	cruises.cruise_line4();
//        	Helper.wait_(1);
        	
        	cruises.room_exp();
        	Helper.wait_(2);
        	
        	cruises.select_europe_night();
        	Helper.wait_(2);
        	Browser.return_to_Tab(1);
        	Helper.wait_(2);
        	cruises.continue_button();
        	Helper.wait_(2);
        	cruises.select_room_night();
        	Helper.wait_(2);
        	Browser.return_to_Tab(2);
        	Helper.wait_(2);
        	cruises.reserve();
        	Helper.wait_(2);
        	
        	cruises.country();
        	Helper.wait_(2);
        	cruises.option_country();
        	Helper.wait_(2);
        	cruises.title();
        	Helper.wait_(2);
        	cruises.option_title();
        	Helper.wait_(2);
        	cruises.gender();
        	Helper.wait_(2);
        	cruises.option_gender();
        	Helper.wait_(2);
        	cruises.birth_month();
        	Helper.wait_(2);
        	cruises.option_birth_month();
        	Helper.wait_(2);
        	cruises.birth_day();
        	Helper.wait_(2);
        	cruises.option_birth_day();
        	Helper.wait_(2);
        	cruises.birth_year();
        	Helper.wait_(2);
        	cruises.option_birth_year();
        	Helper.wait_(2);
        	cruises.country_code();
        	Helper.wait_(2);
        	cruises.country_code_option();
        	Helper.wait_(2);
        	cruises.phone("01118712681");
        	Helper.wait_(2);
        	
        	cruises.title2();
        	Helper.wait_(2);
        	cruises.option_title2();
        	cruises.firstName("Ahmed");
        	Helper.wait_(2);
        	cruises.lastName("Khaled");
        	Helper.wait_(2);
        	cruises.country2();
        	Helper.wait_(2);
        	cruises.option_country2();
        	Helper.wait_(2);
        	cruises.title2();
        	Helper.wait_(2);
        	cruises.option_title2();
        	Helper.wait_(2);
        	cruises.gender2();
        	Helper.wait_(2);
        	cruises.option_gender2();
        	Helper.wait_(2);
        	cruises.birth_month2();
        	Helper.wait_(2);
        	cruises.option_birth_month2();
        	Helper.wait_(2);
        	cruises.birth_day2();
        	Helper.wait_(2);
        	cruises.option_birth_day2();
        	Helper.wait_(2);
        	cruises.birth_year2();
        	Helper.wait_(2);
        	cruises.option_birth_year2();
        	Helper.wait_(2);
        	
        	packages.car_protection();
//        	cruises.nameonCard("Mohamed Mamdouh Helmy");
        	packages.enter_usercardNumber("0239291120313");
        	
        	packages.exp_month();
        	packages.option_exp_month();
        	Helper.wait_(1);
        	
        	packages.exp_year();
        	packages.option_exp_year();
        	Helper.wait_(1);

        	packages.enter_sec_code("334");
        	
        	Helper.wait_(1);


        	cruises.enter_billingAdress1("agakddq123");
        	Helper.wait_(1);

        	cruises.enter_billingAdress2("alskdp230");
        	Helper.wait_(1);

        	packages.enter_city("morano");
        	
        	packages.enter_state("AL");
        	Helper.wait_(1);

        	packages.enter_zip_code("12511");
        	packages.remember_card();
        	
    	    scanner.nextLine(); // ينتظر إدخال المستخدم

            String actualResult =   Browser.getUrl();
            String expectedResult = "https://www.travelocity.com/";

            assertNotEquals(expectedResult, actualResult);
            
         

        }
         if (shouldSucceed=false) {
        	loginPage.disableLoginButton();
        	Helper.wait_(2);
        	
            WebElement element = driver.findElement(By.tagName("h1"));
            String actualResult = element.getText();
            
            String expectedResult = "Sign in";

            assertEquals(expectedResult, actualResult);
        }
    
        
        
        
        
        
       
    }

  
}