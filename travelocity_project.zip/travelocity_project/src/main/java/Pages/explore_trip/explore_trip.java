package Pages.explore_trip;

import Pages.Base.ElementsActions;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.stays.checkout_recommended_stays;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class explore_trip {
    WebDriver driver;
    //contractor
    public explore_trip (WebDriver driver)
    {
        this.driver = driver;
    }
    
    private By find_trip_button =By.cssSelector("a[href='/lp/b/guarantee?pwaLob=wizard-hotel-pwa-v2#editorial-3?rfrr=call-to-action.Find_your perfect trip.click']");
    private By book_flexibility_button =By.xpath("//a[.//span[text()='Book with flexibility']]");
    private By got_yourBack_button =By.xpath("//a[.//span[text()=\"We've got your back\"]]");
    private By inclusiveResorts_button =By.xpath("//a[@href=\"https://www.travelocity.com/lp/deals/all-inclusive?pwaLob=wizard-hotel-pwa\" and text()=\"View deals\"]\r\n"
    		+ "");
    private By lastMinute_button =By.xpath("//a[@href=\"https://www.travelocity.com/lp/deals/last-minute\" and text()=\"View deals\"]\r\n"
    		+ "");
    
    private By start_Plan_Sunny_offer_button =By.cssSelector("a[href='https://www.travelocity.com/lp/deals/beach?rfrr=editorial.Sunny_beach hotel offers.click']");
    private By start_Plan_Car_rental_button =By.xpath("//a[@class='uitk-card-link']/span[text()='Car rental deals']");
    private By start_Plan_Member_disc_button =By.cssSelector("a[href='https://www.travelocity.com/member-discounts?rfrr=editorial.Member_discounts.click']");
    private By start_Plan_vacation_rental_button =By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[4]/div/div[10]/div/div/div[4]/div/div/div/div/a");

    private By change_cancel_trip_button =By.xpath("//button[span[text()='Change or cancel a trip']]");
    private By use_credit_Coupon_button =By.xpath("//button[span[text()='Use a credit or coupon']]");
    private By track_refund_button =By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[4]/div/div[13]/div/div/div/div/section/div/div/div[3]");
     

    //Actions
    public explore_trip scrollPage() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        int scrollPause = 200; // Time to pause between scrolls in milliseconds
        int scrollStep = 200;  // Number of pixels to scroll in each step

        Object lastScrollPositionObj = js.executeScript("return window.pageYOffset;");
        double lastScrollPosition = toDouble(lastScrollPositionObj);
        double newScrollPosition;

        while (true) {
            js.executeScript("window.scrollBy(0, arguments[0]);", scrollStep);
            Thread.sleep(scrollPause);

            Object newScrollPositionObj = js.executeScript("return window.pageYOffset;");
            newScrollPosition = toDouble(newScrollPositionObj);

            if (Math.abs(newScrollPosition - lastScrollPosition) < scrollStep) {
                // If scrolling has reached the end of the page or no further scroll
                break;
            }

            lastScrollPosition = newScrollPosition;
        }

        System.out.println("Scrolling complete.");
        return this;
    }
    
    public explore_trip scroll_And_find_trip_button() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        int scrollPause = 200; // Time to pause between scrolls in milliseconds
        int scrollStep = 200;  // Number of pixels to scroll in each step

        Object lastScrollPositionObj = js.executeScript("return window.pageYOffset;");
        double lastScrollPosition = toDouble(lastScrollPositionObj);
        double newScrollPosition;

        boolean buttonFound = false;

        while (!buttonFound) {
            js.executeScript("window.scrollBy(0, arguments[0]);", scrollStep);
            Thread.sleep(scrollPause);

            Object newScrollPositionObj = js.executeScript("return window.pageYOffset;");
            newScrollPosition = toDouble(newScrollPositionObj);

            if (Math.abs(newScrollPosition - lastScrollPosition) < scrollStep) {
                break;
            }

            lastScrollPosition = newScrollPosition;

            try {
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(find_trip_button));

                if (isElementInViewport(button, driver)) {
                    System.out.println("Button is in view. Clicking on it now.");
                    button.click();
                    buttonFound = true;
                    System.out.println("Button clicked.");
                }
            } catch (StaleElementReferenceException e) {
                // Handle the case where the element reference is stale
                System.out.println("StaleElementReferenceException caught. Trying to find the button again.");
            } catch (NoSuchElementException e) {
                // Handle the case where the element is not found
                System.out.println("Button not found in this iteration.");
            }
        }

        System.out.println("Scrolling and button click actions complete.");
        return this;
    }
    public explore_trip book_flexibility_button() {
        Helper.waitForElement(driver, book_flexibility_button);
        ElementsActions.clicker(driver, book_flexibility_button);
        return this;
    }
    
    public explore_trip got_yourBack_button() {
        Helper.waitForElement(driver, got_yourBack_button);
        ElementsActions.clicker(driver, got_yourBack_button);
        return this;
    }
    
    public explore_trip inclusiveResorts_button() {
        Helper.waitForElement(driver, inclusiveResorts_button);
        ElementsActions.clicker(driver, inclusiveResorts_button);
        return this;
    }
    
    public explore_trip lastMinute_button() {
        Helper.waitForElement(driver, lastMinute_button);
        ElementsActions.clicker(driver, lastMinute_button);
        return this;
    }

    public explore_trip start_Plan_Sunny_offer_button() {
        Helper.waitForElement(driver, start_Plan_Sunny_offer_button);
        ElementsActions.clicker(driver, start_Plan_Sunny_offer_button);
        return this;
    }
    
    public explore_trip start_Plan_Car_rental_button() {
        Helper.waitForElement(driver, start_Plan_Car_rental_button);
        ElementsActions.clicker(driver, start_Plan_Car_rental_button);
        return this;
    }
    
    
    public explore_trip start_Plan_Member_disc_button() {
        Helper.waitForElement(driver, start_Plan_Member_disc_button);
        ElementsActions.clicker(driver, start_Plan_Member_disc_button);
        return this;
    }
    
    
    public explore_trip start_Plan_vacation_rental_button() {
        Helper.waitForElement(driver, start_Plan_vacation_rental_button);
        ElementsActions.clicker(driver, start_Plan_vacation_rental_button);
        return this;
    }
    
    public explore_trip change_cancel_trip_button() {
        Helper.waitForElement(driver, change_cancel_trip_button);
        ElementsActions.clicker(driver, change_cancel_trip_button);
        return this;
    }
    
    
    public explore_trip use_credit_Coupon_button() {
        Helper.waitForElement(driver, use_credit_Coupon_button);
        ElementsActions.clicker(driver, use_credit_Coupon_button);
        return this;
    }
    
    public explore_trip track_refund_button() {
        Helper.waitForElement(driver, track_refund_button);
        ElementsActions.clicker(driver, track_refund_button);
        return this;
    }
    // Helper method to convert Object to double
    private static double toDouble(Object obj) {
        if (obj instanceof Number) {
            return ((Number) obj).doubleValue();
        }
        throw new IllegalArgumentException("Object is not a number");
    }

    // Helper method to check if an element is in the viewport
    private static boolean isElementInViewport(WebElement element, WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        return (Boolean) js.executeScript(
            "var rect = arguments[0].getBoundingClientRect();" +
            "return (rect.top >= 0 && rect.left >= 0 && " +
            "rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) && " +
            "rect.right <= (window.innerWidth || document.documentElement.clientWidth));",
            element
        );
    }
    


}


