package Pages.thing_toDo;

import Pages.Base.ElementsActions;
import Pages.Base.Helper;
import Pages.Login.LoginPage;
import Pages.stays.checkout_recommended_stays;
import Pages.stays.recommended_Stays;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.IOException;

public class thing_toDo {
    WebDriver driver;
    LoginPage page;
    //contractor
    public thing_toDo (WebDriver driver)
    {
        this.driver = driver;
    }
    private By thing_toDo_button = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[1]/ul/li[5]/a");

    private By going_to = By.xpath("//button[@aria-label='Going to' and @aria-expanded='false' and @data-stid='destination_form_field-menu-trigger']");
    private By going_to_city = By.id("destination_form_field");
    private By going_to_city2 = By.xpath("//button[@aria-label='Search for “Alexandria (and vicinity), Alexandria Governorate, Egypt”\r\n"
    		+ "']");
    private By dates = By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div/div/div/div/div/div[2]/div/form/div/div/div[2]/div/div/div/div/button");
    private By done = By.cssSelector("[data-stid='apply-date-selector']");
  
    private By search_button = By.cssSelector("#search_button");
    
    private By search_alex = By.id("slimSearchKeyword");
    
    private By cruouse_right = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div[2]/div/section/section/section[3]/div[2]/div[2]/button[2]");
   
    private By alex_tour1 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div[2]/div/section/section/section[3]/div[2]/div[2]/button[2]");
    private By book_alex_tour1 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div/div[2]/div/section[6]/div/div/div[6]/div[3]/div[2]/button");

    private By alex_tour2 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div[2]/div/section/section/section[4]/div/section/div[3]/a");
    private By book_alex_tour2 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div/div[2]/div/section[6]/div/div/div[6]/div[3]/div[2]/button");
   
    private By alex_tour3 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div[2]/div/section/section/section[4]/div/section/div[20]/a");
    private By book_alex_tour3 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div/div[2]/div/section[6]/div/div/div[5]/div[3]/div[2]/button");
   
    private By alex_tour4 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div[2]/div/section/section/section[4]/div/section/div[23]/a");
    private By book_alex_tour4 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div/div[2]/div/section[6]/div/div/div[4]/div[3]/div[2]/button");

    private By alex_tour5 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div[2]/div/section/section/section[4]/div/section/div[39]/a");
    private By book_alex_tour5 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div/div[2]/div/section[6]/div/div/div[3]/div[3]/div[2]/button");

    private By see_all_alex_tours = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div[2]/div/section/section/div/button");

    private By alex_tour6 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div[2]/div/section/section/section[4]/div/section/div[59]/a");
    private By book_alex_tour6 = By.xpath("/html/body/div[2]/div[1]/div/main/div[2]/div/div[2]/div/section[6]/div/div/div[3]/div[3]/div[2]/button");

    //Actions

    public thing_toDo thing_toDo_button()
    {
        Helper.waitForElement(driver, thing_toDo_button);
        ElementsActions.clicker(driver, thing_toDo_button);
        return  this;
    }

    
    public thing_toDo going_to(){
    	Helper.waitForElement(driver , going_to);
        ElementsActions.clicker(driver, going_to);
//        driver.findElement(going_to_city).sendKeys(Keys.RETURN);
    	return this;
    	}
    
    public thing_toDo going_to_city( String fieldName) throws IOException, ParseException {
    	Helper.waitForElement(driver , going_to_city);
    	ElementsActions.sendText(driver , going_to_city , fieldName);
      driver.findElement(going_to_city).sendKeys(Keys.ENTER);
    	return this;
    	}
    public thing_toDo going_to_city2(){
    	Helper.waitForElement(driver , going_to_city2);
        ElementsActions.clicker(driver, going_to_city2);
    	return this;
    	}
    public thing_toDo clickOndates()
    {
        Helper.waitForElement(driver, dates);
        ElementsActions.clicker(driver, dates);
        return  this;
    }
    public thing_toDo clickOnchoose_done()
    {
        Helper.waitForElement(driver, done);
        ElementsActions.clicker(driver, done);
        return  this;
    }

public thing_toDo clickOnsearch_button()
{
    Helper.waitForElement(driver, search_button);
    ElementsActions.clicker(driver, search_button);
    return  this;
}
public thing_toDo search_alex( String fieldName) throws IOException, ParseException {
	Helper.waitForElement(driver , search_alex);
    ElementsActions.clicker(driver, search_alex);
	ElementsActions.sendText(driver , search_alex , fieldName);
    driver.findElement(search_alex).sendKeys(Keys.RETURN);
	return this;
	}
public thing_toDo cruouse_right()
{
    Helper.waitForElement(driver, cruouse_right);
    ElementsActions.clicker(driver, cruouse_right);
    return  this;
}
public thing_toDo alex_tour1()
{
    Helper.waitForElement(driver, alex_tour1);
    ElementsActions.clicker(driver, alex_tour1);
    return  this;
}
public thing_toDo book_alex_tour1()
{
    Helper.waitForElement(driver, book_alex_tour1);
    ElementsActions.clicker(driver, book_alex_tour1);
    return  this;
}
public thing_toDo book_alex_tour2()
{
    Helper.waitForElement(driver, book_alex_tour2);
    ElementsActions.clicker(driver, book_alex_tour2);
    return  this;
}
public thing_toDo alex_tour2()
{
    Helper.waitForElement(driver, alex_tour2);
    ElementsActions.clicker(driver, alex_tour2);
    return  this;
}
public thing_toDo book_alex_tour3()
{
    Helper.waitForElement(driver, book_alex_tour3);
    ElementsActions.clicker(driver, book_alex_tour3);
    return  this;
}
public thing_toDo alex_tour3()
{
    Helper.waitForElement(driver, alex_tour3);
    ElementsActions.clicker(driver, alex_tour3);
    return  this;
}
public thing_toDo book_alex_tour4()
{
    Helper.waitForElement(driver, book_alex_tour4);
    ElementsActions.clicker(driver, book_alex_tour4);
    return  this;
}
public thing_toDo alex_tour4()
{
    Helper.waitForElement(driver, alex_tour4);
    ElementsActions.clicker(driver, alex_tour4);
    return  this;
}
public thing_toDo book_alex_tour5()
{
    Helper.waitForElement(driver, book_alex_tour5);
    ElementsActions.clicker(driver, book_alex_tour5);
    return  this;
}
public thing_toDo alex_tour5()
{
    Helper.waitForElement(driver, alex_tour5);
    ElementsActions.clicker(driver, alex_tour5);
    return  this;
}
public thing_toDo book_alex_tour6()
{
    Helper.waitForElement(driver, book_alex_tour6);
    ElementsActions.clicker(driver, book_alex_tour6);
    return  this;
}
public thing_toDo alex_tour6()
{
    Helper.waitForElement(driver, alex_tour6);
    ElementsActions.clicker(driver, alex_tour6);
    return  this;
}

public thing_toDo see_all_alex_tours()
{
    Helper.waitForElement(driver, see_all_alex_tours);
    ElementsActions.clicker(driver, see_all_alex_tours);
    return  this;
}

}


