package TC_Pages.TC_morethanScenario;
import Pages.Base.Browser;
import Pages.Base.Helper;
import Pages.Login.LoginScenario;
import Pages.morethanScenario.login_with_book_StaysPage;
import Pages.morethanScenario.login_with_explore_tripPage;
import Pages.morethanScenario.login_with_flighPage;
import Pages.morethanScenario.login_with_recommended_stays;
import io.qameta.allure.*;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

@Epic("zzz")
@Feature("Login Page")
public class TC_login_with_flightPage {
    private WebDriver driver;
    login_with_flighPage login;
    
    @BeforeMethod
    public void setBrowser()
    {
        driver = Browser.setBrowser();
        login = new login_with_flighPage(driver);
    }

    @Test (description = "try to login with valid and invalid data", dataProvider = "login", dataProviderClass = login_with_flighPage.class)
    @Story("Login with exist account")
    @Description("after the user create account he will try to login with valid data")
    @Severity(SeverityLevel.CRITICAL)
    public void login(String usernameEmail, String password, boolean shouldSucceed) throws IOException, ParseException, InterruptedException {
        login.login(usernameEmail, password, shouldSucceed);
    }
        @AfterMethod
    public void quit()
    {
        Browser.quit();
    }

}
